     <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Download Error - World Wars</title>
        <link rel="icon" type="image/x-icon" href="favicon.77eae63f.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body class="bg-dark">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card bg-dark text-light border-danger">
                        <div class="card-body text-center">
                            <i class="fas fa-exclamation-circle text-danger fa-3x mb-3"></i>
                            <h3 class="card-title">Download Error</h3>
                            <p class="card-text">We apologize, but there was an error processing your download request.</p>
                            <p class="text-danger">Game file not found. Please try again later.</p>
                            <div class="mt-4">
                                <a href="index.php" class="btn btn-primary me-2">
                                    <i class="fas fa-home me-2"></i>Return to Homepage
                                </a>
                                <a href="javascript:history.back()" class="btn btn-outline-light">
                                    <i class="fas fa-arrow-left me-2"></i>Go Back
                                </a>
                            </div>
                                                        <div class="mt-4 text-start">
                                <small class="text-muted">Debug information:</small>
                                <pre class="text-light bg-dark p-3 mt-2" style="font-size: 0.8rem;">
                                    [2025-02-06 19:51:30] Starting download process...
[2025-02-06 19:51:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 92.222.9.185
    [REMOTE_PORT] =&gt; 39892
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; HEAD
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738871490.6305
    [REQUEST_TIME] =&gt; 1738871490
)

[2025-02-06 19:51:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-06 19:51:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-06 19:51:30] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-06 19:51:30] Error occurred: Game file not found. Please try again later.
[2025-02-06 19:51:30] Starting download process...
[2025-02-06 19:51:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 92.222.9.185
    [REMOTE_PORT] =&gt; 39892
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738871490.6827
    [REQUEST_TIME] =&gt; 1738871490
)

[2025-02-06 19:51:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-06 19:51:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-06 19:51:30] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-06 19:51:30] Error occurred: Game file not found. Please try again later.
[2025-02-06 19:55:09] Starting download process...
[2025-02-06 19:55:09] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 92.222.9.185
    [REMOTE_PORT] =&gt; 48720
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738871709.0232
    [REQUEST_TIME] =&gt; 1738871709
)

[2025-02-06 19:55:09] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-06 19:55:09] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-06 19:55:09] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-06 19:55:09] Error occurred: Game file not found. Please try again later.
[2025-02-06 19:55:15] Starting download process...
[2025-02-06 19:55:15] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 92.222.9.185
    [REMOTE_PORT] =&gt; 54908
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738871715.9193
    [REQUEST_TIME] =&gt; 1738871715
)

[2025-02-06 19:55:15] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-06 19:55:15] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-06 19:55:15] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-06 19:55:15] Error occurred: Game file not found. Please try again later.
[2025-02-07 00:54:19] Starting download process...
[2025-02-07 00:54:19] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 94.110.79.231
    [REMOTE_PORT] =&gt; 51449
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738889659.5796
    [REQUEST_TIME] =&gt; 1738889659
)

[2025-02-07 00:54:19] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-07 00:54:19] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-07 00:54:19] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-07 00:54:19] Error occurred: Game file not found. Please try again later.
[2025-02-07 03:06:36] Starting download process...
[2025-02-07 03:06:36] Server variables: Array
(
    [MIBDIRS] =&gt; C:/xampp/php/extras/mibs
    [MYSQL_HOME] =&gt; \xampp\mysql\bin
    [OPENSSL_CONF] =&gt; C:/xampp/apache/bin/openssl.cnf
    [PHP_PEAR_SYSCONF_DIR] =&gt; \xampp\php
    [PHPRC] =&gt; \xampp\php
    [TMP] =&gt; \xampp\tmp
    [HTTP_HOST] =&gt; localhost
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_REFERER] =&gt; http://localhost/
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [PATH] =&gt; C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Windows\System32\OpenSSH\;C:\Program Files\NVIDIA Corporation\NVIDIA app\NvDLISR;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;C:\Users\kwayse\AppData\Local\Microsoft\WindowsApps;C:\Users\kwayse\AppData\Local\spicetify;C:\Users\kwayse\AppData\Local\Programs\Microsoft VS Code\bin
    [SystemRoot] =&gt; C:\Windows
    [COMSPEC] =&gt; C:\Windows\system32\cmd.exe
    [PATHEXT] =&gt; .COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC
    [WINDIR] =&gt; C:\Windows
    [SERVER_SIGNATURE] =&gt; &lt;address&gt;Apache/2.4.58 (Win64) OpenSSL/3.1.3 PHP/8.2.12 Server at localhost Port 80&lt;/address&gt;

    [SERVER_SOFTWARE] =&gt; Apache/2.4.58 (Win64) OpenSSL/3.1.3 PHP/8.2.12
    [SERVER_NAME] =&gt; localhost
    [SERVER_ADDR] =&gt; ::1
    [SERVER_PORT] =&gt; 80
    [REMOTE_ADDR] =&gt; ::1
    [DOCUMENT_ROOT] =&gt; C:/Users/kwayse/Desktop/newfolder
    [REQUEST_SCHEME] =&gt; http
    [CONTEXT_PREFIX] =&gt; 
    [CONTEXT_DOCUMENT_ROOT] =&gt; C:/Users/kwayse/Desktop/newfolder
    [SERVER_ADMIN] =&gt; postmaster@localhost
    [SCRIPT_FILENAME] =&gt; C:/Users/kwayse/Desktop/newfolder/direct-download.php
    [REMOTE_PORT] =&gt; 54682
    [GATEWAY_INTERFACE] =&gt; CGI/1.1
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [REQUEST_METHOD] =&gt; GET
    [QUERY_STRING] =&gt; 
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738893996.2141
    [REQUEST_TIME] =&gt; 1738893996
)

[2025-02-07 03:06:36] Game file info: Array
(
    [path] =&gt; C:\Users\kwayse\Desktop\newfolder/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://localhost\/downloads/WorldWars.rar
)

[2025-02-07 03:06:36] Downloads directory checked: C:\Users\kwayse\Desktop\newfolder/downloads
[2025-02-07 03:06:36] Game file not found at: C:\Users\kwayse\Desktop\newfolder/downloads/WorldWars.rar
[2025-02-07 03:06:36] Error occurred: Game file not found. Please try again later.
[2025-02-08 00:23:16] Starting download process...
[2025-02-08 00:23:16] Server variables: Array
(
    [MIBDIRS] =&gt; C:/xampp/php/extras/mibs
    [MYSQL_HOME] =&gt; \xampp\mysql\bin
    [OPENSSL_CONF] =&gt; C:/xampp/apache/bin/openssl.cnf
    [PHP_PEAR_SYSCONF_DIR] =&gt; \xampp\php
    [PHPRC] =&gt; \xampp\php
    [TMP] =&gt; \xampp\tmp
    [HTTP_HOST] =&gt; localhost
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_REFERER] =&gt; http://localhost/
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [PATH] =&gt; C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files\NVIDIA Corporation\NVIDIA app\NvDLISR;C:\Program Files (x86)\NVIDIA Corporation\PhysX\Common;C:\Users\kwayse\AppData\Local\Microsoft\WindowsApps;;C:\Users\kwayse\AppData\Local\spicetify;C:\Users\kwayse\AppData\Local\Programs\Microsoft VS Code\bin;C:\Users\kwayse\AppData\Local\Microsoft\WindowsApps
    [SystemRoot] =&gt; C:\WINDOWS
    [COMSPEC] =&gt; C:\WINDOWS\system32\cmd.exe
    [PATHEXT] =&gt; .COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC
    [WINDIR] =&gt; C:\WINDOWS
    [SERVER_SIGNATURE] =&gt; &lt;address&gt;Apache/2.4.58 (Win64) OpenSSL/3.1.3 PHP/8.2.12 Server at localhost Port 80&lt;/address&gt;

    [SERVER_SOFTWARE] =&gt; Apache/2.4.58 (Win64) OpenSSL/3.1.3 PHP/8.2.12
    [SERVER_NAME] =&gt; localhost
    [SERVER_ADDR] =&gt; ::1
    [SERVER_PORT] =&gt; 80
    [REMOTE_ADDR] =&gt; ::1
    [DOCUMENT_ROOT] =&gt; C:/Users/kwayse/Desktop/newfolder
    [REQUEST_SCHEME] =&gt; http
    [CONTEXT_PREFIX] =&gt; 
    [CONTEXT_DOCUMENT_ROOT] =&gt; C:/Users/kwayse/Desktop/newfolder
    [SERVER_ADMIN] =&gt; postmaster@localhost
    [SCRIPT_FILENAME] =&gt; C:/Users/kwayse/Desktop/newfolder/direct-download.php
    [REMOTE_PORT] =&gt; 58662
    [GATEWAY_INTERFACE] =&gt; CGI/1.1
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [REQUEST_METHOD] =&gt; GET
    [QUERY_STRING] =&gt; 
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738970596.1029
    [REQUEST_TIME] =&gt; 1738970596
)

[2025-02-08 00:23:16] Game file info: Array
(
    [path] =&gt; C:\Users\kwayse\Desktop\newfolder/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://localhost\/downloads/WorldWars.rar
)

[2025-02-08 00:23:16] Downloads directory checked: C:\Users\kwayse\Desktop\newfolder/downloads
[2025-02-08 00:23:16] Game file not found at: C:\Users\kwayse\Desktop\newfolder/downloads/WorldWars.rar
[2025-02-08 00:23:16] Error occurred: Game file not found. Please try again later.
[2025-02-08 00:21:47] Starting download process...
[2025-02-08 00:21:47] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.142 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; none
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 40.80.158.10
    [REMOTE_PORT] =&gt; 43712
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738974107.3389
    [REQUEST_TIME] =&gt; 1738974107
)

[2025-02-08 00:21:47] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 00:21:47] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 00:21:47] File size: 76.63 MB
[2025-02-08 00:21:47] Download count incremented to: 11
[2025-02-08 00:21:47] Headers set for download
[2025-02-08 00:21:47] Starting file output
[2025-02-08 00:21:55] File output complete. Total bytes read: 76.63 MB
[2025-02-08 01:19:51] Starting download process...
[2025-02-08 01:19:51] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6795.72 Safari/537.36 Edg/131.0.2898.111
    [HTTP_SEC_CH_UA] =&gt; &quot;(Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;131&quot;, &quot;Chromium&quot;;v=&quot;131&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;macOS&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_CH_UA_FULL_VERSION_LIST] =&gt; &quot;(Not(A:Brand&quot;;v=&quot;99.0.0.0&quot;, &quot;Microsoft Edge&quot;;v=&quot;131&quot;, &quot;Chromium&quot;;v=&quot;131&quot;
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.47.234.97
    [REMOTE_PORT] =&gt; 47266
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738977591.437
    [REQUEST_TIME] =&gt; 1738977591
)

[2025-02-08 01:19:51] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 01:19:51] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 01:19:51] File size: 76.63 MB
[2025-02-08 01:19:51] Download count incremented to: 12
[2025-02-08 01:19:51] Headers set for download
[2025-02-08 01:19:51] Starting file output
[2025-02-08 01:20:02] File output complete. Total bytes read: 76.63 MB
[2025-02-08 03:59:48] Starting download process...
[2025-02-08 03:59:48] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_COOKIE] =&gt; HandLtestDomainNameServer=HandLtestDomainValueServer; handl_ip=213.136.71.30; handl_landing_page=https%3A%2F%2Fdemandscience.com%2F; handl_url=https%3A%2F%2Fdemandscience.com%2F; handl_url_base=https%3A%2F%2Fdemandscience.com%2F; user_agent=Mozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F91.0.4472.124%20Safari%2F537.36
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 37.59.238.189
    [REMOTE_PORT] =&gt; 44968
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1738987188.4791
    [REQUEST_TIME] =&gt; 1738987188
)

[2025-02-08 03:59:48] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 03:59:48] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 03:59:48] File size: 76.63 MB
[2025-02-08 03:59:48] Download count incremented to: 13
[2025-02-08 03:59:48] Headers set for download
[2025-02-08 03:59:48] Starting file output
[2025-02-08 11:49:57] Starting download process...
[2025-02-08 11:49:57] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/354.0.720749604 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.154.57.132
    [REMOTE_PORT] =&gt; 22148
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739015396.9576
    [REQUEST_TIME] =&gt; 1739015396
)

[2025-02-08 11:49:57] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 11:49:57] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 11:49:57] File size: 76.63 MB
[2025-02-08 11:49:57] Download count incremented to: 14
[2025-02-08 11:49:57] Headers set for download
[2025-02-08 11:49:57] Starting file output
[2025-02-08 11:49:59] Starting download process...
[2025-02-08 11:49:59] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/354.0.720749604 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.154.57.132
    [REMOTE_PORT] =&gt; 22148
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739015398.6899
    [REQUEST_TIME] =&gt; 1739015398
)

[2025-02-08 11:49:59] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 11:49:59] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 11:49:59] File size: 76.63 MB
[2025-02-08 11:49:59] Download count incremented to: 15
[2025-02-08 11:49:59] Headers set for download
[2025-02-08 11:49:59] Starting file output
[2025-02-08 11:50:00] Starting download process...
[2025-02-08 11:50:00] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/354.0.720749604 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.154.57.132
    [REMOTE_PORT] =&gt; 22148
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739015399.9837
    [REQUEST_TIME] =&gt; 1739015399
)

[2025-02-08 11:50:00] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 11:50:00] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 11:50:00] File size: 76.63 MB
[2025-02-08 11:50:00] Download count incremented to: 16
[2025-02-08 11:50:00] Headers set for download
[2025-02-08 11:50:00] Starting file output
[2025-02-08 11:50:03] Starting download process...
[2025-02-08 11:50:03] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/354.0.720749604 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.154.57.132
    [REMOTE_PORT] =&gt; 22148
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739015403.0525
    [REQUEST_TIME] =&gt; 1739015403
)

[2025-02-08 11:50:03] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 11:50:03] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 11:50:03] File size: 76.63 MB
[2025-02-08 11:50:03] Download count incremented to: 17
[2025-02-08 11:50:03] Headers set for download
[2025-02-08 11:50:03] Starting file output
[2025-02-08 11:50:05] File output complete. Total bytes read: 76.63 MB
[2025-02-08 11:50:05] File output complete. Total bytes read: 76.63 MB
[2025-02-08 11:50:05] Starting download process...
[2025-02-08 11:50:05] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/354.0.720749604 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.154.57.132
    [REMOTE_PORT] =&gt; 22148
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739015404.8483
    [REQUEST_TIME] =&gt; 1739015404
)

[2025-02-08 11:50:05] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 11:50:05] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 11:50:05] File size: 76.63 MB
[2025-02-08 11:50:05] Download count incremented to: 18
[2025-02-08 11:50:05] Headers set for download
[2025-02-08 11:50:05] Starting file output
[2025-02-08 11:50:06] Starting download process...
[2025-02-08 11:50:06] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/354.0.720749604 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.154.57.132
    [REMOTE_PORT] =&gt; 22148
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739015405.5814
    [REQUEST_TIME] =&gt; 1739015405
)

[2025-02-08 11:50:06] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 11:50:06] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 11:50:06] File size: 76.63 MB
[2025-02-08 11:50:06] Download count incremented to: 19
[2025-02-08 11:50:06] Headers set for download
[2025-02-08 11:50:06] Starting file output
[2025-02-08 11:50:06] File output complete. Total bytes read: 76.63 MB
[2025-02-08 11:50:08] File output complete. Total bytes read: 76.63 MB
[2025-02-08 11:50:08] File output complete. Total bytes read: 76.63 MB
[2025-02-08 16:30:30] Starting download process...
[2025-02-08 16:30:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 11; CPH2185) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Mobile Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 123.6.49.18
    [REMOTE_PORT] =&gt; 4834
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739032230.3158
    [REQUEST_TIME] =&gt; 1739032230
)

[2025-02-08 16:30:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-08 16:30:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-08 16:30:30] File size: 76.63 MB
[2025-02-08 16:30:30] Download count incremented to: 20
[2025-02-08 16:30:30] Headers set for download
[2025-02-08 16:30:30] Starting file output
[2025-02-09 00:19:46] Starting download process...
[2025-02-09 00:19:46] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/signed-exchange;v=b3,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.159 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)
    [HTTP_AMP_CACHE_TRANSFORM] =&gt; google;v=&quot;1..8&quot;
    [HTTP_FROM] =&gt; googlebot(at)googlebot.com
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 66.249.77.39
    [REMOTE_PORT] =&gt; 35224
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739060386.3166
    [REQUEST_TIME] =&gt; 1739060386
)

[2025-02-09 00:19:46] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 00:19:46] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 00:19:46] File size: 76.63 MB
[2025-02-09 00:19:46] Download count incremented to: 21
[2025-02-09 00:19:46] Headers set for download
[2025-02-09 00:19:46] Starting file output
[2025-02-09 00:29:01] Starting download process...
[2025-02-09 00:29:01] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.250.207.88
    [REMOTE_PORT] =&gt; 60835
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739060941.0435
    [REQUEST_TIME] =&gt; 1739060941
)

[2025-02-09 00:29:01] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 00:29:01] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 00:29:01] File size: 76.63 MB
[2025-02-09 00:29:01] Download count incremented to: 22
[2025-02-09 00:29:01] Headers set for download
[2025-02-09 00:29:01] Starting file output
[2025-02-09 00:29:17] File output complete. Total bytes read: 76.63 MB
[2025-02-09 01:53:23] Starting download process...
[2025-02-09 01:53:23] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.159 Mobile Safari/537.36 (compatible; GoogleOther)
    [HTTP_FROM] =&gt; googlebot(at)googlebot.com
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 66.249.76.199
    [REMOTE_PORT] =&gt; 48678
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739066003.3092
    [REQUEST_TIME] =&gt; 1739066003
)

[2025-02-09 01:53:23] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 01:53:23] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 01:53:23] File size: 76.63 MB
[2025-02-09 01:53:23] Download count incremented to: 23
[2025-02-09 01:53:23] Headers set for download
[2025-02-09 01:53:23] Starting file output
[2025-02-09 01:53:31] File output complete. Total bytes read: 76.63 MB
[2025-02-09 02:38:23] Starting download process...
[2025-02-09 02:38:23] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.159 Mobile Safari/537.36 (compatible; GoogleOther)
    [HTTP_FROM] =&gt; googlebot(at)googlebot.com
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 66.249.76.196
    [REMOTE_PORT] =&gt; 47590
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739068703.0553
    [REQUEST_TIME] =&gt; 1739068703
)

[2025-02-09 02:38:23] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 02:38:23] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 02:38:23] File size: 76.63 MB
[2025-02-09 02:38:23] Download count incremented to: 24
[2025-02-09 02:38:23] Headers set for download
[2025-02-09 02:38:23] Starting file output
[2025-02-09 02:38:30] File output complete. Total bytes read: 76.63 MB
[2025-02-09 06:43:10] Starting download process...
[2025-02-09 06:43:10] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-us,en-gb,en;q=0.7,*;q=0.3
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; serpstatbot/2.1 (advanced backlink tracking bot; https://serpstatbot.com/; abuse@serpstatbot.com)
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 144.76.67.110
    [REMOTE_PORT] =&gt; 47878
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739083390.3745
    [REQUEST_TIME] =&gt; 1739083390
)

[2025-02-09 06:43:10] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 06:43:10] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 06:43:10] File size: 76.63 MB
[2025-02-09 06:43:10] Download count incremented to: 25
[2025-02-09 06:43:10] Headers set for download
[2025-02-09 06:43:10] Starting file output
[2025-02-09 07:35:03] Starting download process...
[2025-02-09 07:35:03] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.155.160.173
    [REMOTE_PORT] =&gt; 33634
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739086503.1751
    [REQUEST_TIME] =&gt; 1739086503
)

[2025-02-09 07:35:03] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 07:35:03] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 07:35:03] File size: 76.63 MB
[2025-02-09 07:35:03] Download count incremented to: 26
[2025-02-09 07:35:03] Headers set for download
[2025-02-09 07:35:03] Starting file output
[2025-02-09 12:29:05] Starting download process...
[2025-02-09 12:29:05] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 49.51.253.83
    [REMOTE_PORT] =&gt; 48724
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739104144.7411
    [REQUEST_TIME] =&gt; 1739104144
)

[2025-02-09 12:29:05] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 12:29:05] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 12:29:05] File size: 76.63 MB
[2025-02-09 12:29:05] Download count incremented to: 27
[2025-02-09 12:29:05] Headers set for download
[2025-02-09 12:29:05] Starting file output
[2025-02-09 14:22:56] Starting download process...
[2025-02-09 14:22:56] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Vivaldi/5.3.2679.68
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;114&quot;, &quot;Chromium&quot;;v=&quot;114&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;macOS&quot;
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 5.196.160.191
    [REMOTE_PORT] =&gt; 49796
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739110976.001
    [REQUEST_TIME] =&gt; 1739110976
)

[2025-02-09 14:22:56] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-09 14:22:56] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-09 14:22:56] File size: 76.63 MB
[2025-02-09 14:22:56] Download count incremented to: 28
[2025-02-09 14:22:56] Headers set for download
[2025-02-09 14:22:56] Starting file output
[2025-02-10 00:13:30] Starting download process...
[2025-02-10 00:13:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.154.57.132
    [REMOTE_PORT] =&gt; 22068
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739146410.0013
    [REQUEST_TIME] =&gt; 1739146410
)

[2025-02-10 00:13:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 00:13:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 00:13:30] File size: 76.63 MB
[2025-02-10 00:13:30] Download count incremented to: 29
[2025-02-10 00:13:30] Headers set for download
[2025-02-10 00:13:30] Starting file output
[2025-02-10 00:13:39] File output complete. Total bytes read: 76.63 MB
[2025-02-10 00:39:51] Starting download process...
[2025-02-10 00:39:51] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 OPR/116.0.0.0 (Edition std-2)
    [HTTP_SEC_CH_UA] =&gt; &quot;Opera GX&quot;;v=&quot;116&quot;, &quot;Chromium&quot;;v=&quot;131&quot;, &quot;Not_A Brand&quot;;v=&quot;24&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.39.58.138
    [REMOTE_PORT] =&gt; 54839
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739147991.0629
    [REQUEST_TIME] =&gt; 1739147991
)

[2025-02-10 00:39:51] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 00:39:51] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 00:39:51] File size: 76.63 MB
[2025-02-10 00:39:51] Download count incremented to: 30
[2025-02-10 00:39:51] Headers set for download
[2025-02-10 00:39:51] Starting file output
[2025-02-10 00:40:59] Starting download process...
[2025-02-10 00:40:59] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 OPR/116.0.0.0 (Edition std-2)
    [HTTP_SEC_CH_UA] =&gt; &quot;Opera GX&quot;;v=&quot;116&quot;, &quot;Chromium&quot;;v=&quot;131&quot;, &quot;Not_A Brand&quot;;v=&quot;24&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.39.58.138
    [REMOTE_PORT] =&gt; 54839
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739148059.0237
    [REQUEST_TIME] =&gt; 1739148059
)

[2025-02-10 00:40:59] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 00:40:59] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 00:40:59] File size: 76.63 MB
[2025-02-10 00:40:59] Download count incremented to: 31
[2025-02-10 00:40:59] Headers set for download
[2025-02-10 00:40:59] Starting file output
[2025-02-10 00:41:31] File output complete. Total bytes read: 76.63 MB
[2025-02-10 00:42:11] Starting download process...
[2025-02-10 00:42:11] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 OPR/116.0.0.0 (Edition std-2)
    [HTTP_SEC_CH_UA] =&gt; &quot;Opera GX&quot;;v=&quot;116&quot;, &quot;Chromium&quot;;v=&quot;131&quot;, &quot;Not_A Brand&quot;;v=&quot;24&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.39.58.138
    [REMOTE_PORT] =&gt; 54839
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739148131.4767
    [REQUEST_TIME] =&gt; 1739148131
)

[2025-02-10 00:42:11] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 00:42:11] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 00:42:11] File size: 76.63 MB
[2025-02-10 00:42:11] Download count incremented to: 32
[2025-02-10 00:42:11] Headers set for download
[2025-02-10 00:42:11] Starting file output
[2025-02-10 00:44:02] Starting download process...
[2025-02-10 00:44:02] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip,deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0
    [HTTP_FROM] =&gt; support@search.yandex.ru
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 87.250.224.29
    [REMOTE_PORT] =&gt; 39886
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739148242.2871
    [REQUEST_TIME] =&gt; 1739148242
)

[2025-02-10 00:44:02] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 00:44:02] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 00:44:02] File size: 76.63 MB
[2025-02-10 00:44:02] Download count incremented to: 33
[2025-02-10 00:44:02] Headers set for download
[2025-02-10 00:44:02] Starting file output
[2025-02-10 08:17:00] Starting download process...
[2025-02-10 08:17:00] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0
    [HTTP_DNT] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 193.176.84.16
    [REMOTE_PORT] =&gt; 43190
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739175419.8873
    [REQUEST_TIME] =&gt; 1739175419
)

[2025-02-10 08:17:00] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 08:17:00] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 08:17:00] File size: 76.63 MB
[2025-02-10 08:17:00] Download count incremented to: 34
[2025-02-10 08:17:00] Headers set for download
[2025-02-10 08:17:00] Starting file output
[2025-02-10 08:17:08] File output complete. Total bytes read: 76.63 MB
[2025-02-10 10:00:44] Starting download process...
[2025-02-10 10:00:44] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, br, deflate
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.2; +https://openai.com/gptbot)
    [HTTP_X_OPENAI_HOST_HASH] =&gt; 320209467
    [HTTP_FROM] =&gt; gptbot(at)openai.com
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 20.171.207.126
    [REMOTE_PORT] =&gt; 58492
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739181644.0236
    [REQUEST_TIME] =&gt; 1739181644
)

[2025-02-10 10:00:44] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 10:00:44] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 10:00:44] File size: 76.63 MB
[2025-02-10 10:00:44] Download count incremented to: 35
[2025-02-10 10:00:44] Headers set for download
[2025-02-10 10:00:44] Starting file output
[2025-02-10 10:00:55] File output complete. Total bytes read: 76.63 MB
[2025-02-10 15:07:48] Starting download process...
[2025-02-10 15:07:48] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/125.0.6422.60 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 34.122.147.229
    [REMOTE_PORT] =&gt; 9101
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739200068.5735
    [REQUEST_TIME] =&gt; 1739200068
)

[2025-02-10 15:07:48] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 15:07:48] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 15:07:48] File size: 76.63 MB
[2025-02-10 15:07:48] Download count incremented to: 36
[2025-02-10 15:07:48] Headers set for download
[2025-02-10 15:07:48] Starting file output
[2025-02-10 15:39:58] Starting download process...
[2025-02-10 15:39:58] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?1
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Android&quot;
    [HTTP_DNT] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 49.191.142.22
    [REMOTE_PORT] =&gt; 44856
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739201998.0599
    [REQUEST_TIME] =&gt; 1739201998
)

[2025-02-10 15:39:58] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 15:39:58] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 15:39:58] File size: 76.63 MB
[2025-02-10 15:39:58] Download count incremented to: 37
[2025-02-10 15:39:58] Headers set for download
[2025-02-10 15:39:58] Starting file output
[2025-02-10 15:40:20] File output complete. Total bytes read: 76.63 MB
[2025-02-10 16:58:06] Starting download process...
[2025-02-10 16:58:06] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 49.191.142.22
    [REMOTE_PORT] =&gt; 55836
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739206685.7411
    [REQUEST_TIME] =&gt; 1739206685
)

[2025-02-10 16:58:06] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 16:58:06] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 16:58:06] File size: 76.63 MB
[2025-02-10 16:58:06] Download count incremented to: 38
[2025-02-10 16:58:06] Headers set for download
[2025-02-10 16:58:06] Starting file output
[2025-02-10 16:58:21] File output complete. Total bytes read: 76.63 MB
[2025-02-10 18:29:51] Starting download process...
[2025-02-10 18:29:51] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.135.145.77
    [REMOTE_PORT] =&gt; 56326
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739212191.4274
    [REQUEST_TIME] =&gt; 1739212191
)

[2025-02-10 18:29:51] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 18:29:51] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 18:29:51] File size: 76.63 MB
[2025-02-10 18:29:51] Download count incremented to: 39
[2025-02-10 18:29:51] Headers set for download
[2025-02-10 18:29:51] Starting file output
[2025-02-10 22:39:30] Starting download process...
[2025-02-10 22:39:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; 
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.8
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (compatible; Dataprovider.com)
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 144.217.135.131
    [REMOTE_PORT] =&gt; 38223
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739227169.6241
    [REQUEST_TIME] =&gt; 1739227169
)

[2025-02-10 22:39:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-10 22:39:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-10 22:39:30] File size: 76.63 MB
[2025-02-10 22:39:30] Download count incremented to: 40
[2025-02-10 22:39:30] Headers set for download
[2025-02-10 22:39:30] Starting file output
[2025-02-11 00:20:22] Starting download process...
[2025-02-11 00:20:22] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/signed-exchange;v=b3,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.159 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)
    [HTTP_AMP_CACHE_TRANSFORM] =&gt; google;v=&quot;1..8&quot;
    [HTTP_FROM] =&gt; googlebot(at)googlebot.com
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 66.249.79.34
    [REMOTE_PORT] =&gt; 51476
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739233221.7818
    [REQUEST_TIME] =&gt; 1739233221
)

[2025-02-11 00:20:22] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 00:20:22] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 00:20:22] File size: 76.63 MB
[2025-02-11 00:20:22] Download count incremented to: 41
[2025-02-11 00:20:22] Headers set for download
[2025-02-11 00:20:22] Starting file output
[2025-02-11 14:12:52] Starting download process...
[2025-02-11 14:12:52] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 15_8_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.6 Mobile/15E148 Safari/604.1
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.242.162.178
    [REMOTE_PORT] =&gt; 26250
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739283171.5075
    [REQUEST_TIME] =&gt; 1739283171
)

[2025-02-11 14:12:52] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 14:12:52] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 14:12:52] File size: 76.63 MB
[2025-02-11 14:12:52] Download count incremented to: 42
[2025-02-11 14:12:52] Headers set for download
[2025-02-11 14:12:52] Starting file output
[2025-02-11 14:13:02] File output complete. Total bytes read: 76.63 MB
[2025-02-11 19:00:36] Starting download process...
[2025-02-11 19:00:36] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36
    [HTTP_FROM] =&gt; bingbot(at)microsoft.com
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 52.167.144.222
    [REMOTE_PORT] =&gt; 5886
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739300435.7489
    [REQUEST_TIME] =&gt; 1739300435
)

[2025-02-11 19:00:36] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 19:00:36] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 19:00:36] File size: 76.63 MB
[2025-02-11 19:00:36] Download count incremented to: 43
[2025-02-11 19:00:36] Headers set for download
[2025-02-11 19:00:36] Starting file output
[2025-02-11 19:05:10] Starting download process...
[2025-02-11 19:05:10] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Microsoft Edge&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; cross-site
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 185.254.75.48
    [REMOTE_PORT] =&gt; 57719
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739300709.9162
    [REQUEST_TIME] =&gt; 1739300709
)

[2025-02-11 19:05:10] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 19:05:10] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 19:05:10] File size: 76.63 MB
[2025-02-11 19:05:10] Download count incremented to: 44
[2025-02-11 19:05:10] Headers set for download
[2025-02-11 19:05:10] Starting file output
[2025-02-11 19:05:43] File output complete. Total bytes read: 76.63 MB
[2025-02-11 19:19:14] Starting download process...
[2025-02-11 19:19:14] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Microsoft Edge&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; cross-site
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 185.254.75.48
    [REMOTE_PORT] =&gt; 57963
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739301554.2261
    [REQUEST_TIME] =&gt; 1739301554
)

[2025-02-11 19:19:14] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 19:19:14] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 19:19:14] File size: 76.63 MB
[2025-02-11 19:19:14] Download count incremented to: 45
[2025-02-11 19:19:14] Headers set for download
[2025-02-11 19:19:14] Starting file output
[2025-02-11 21:24:30] Starting download process...
[2025-02-11 21:24:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.159.128.237
    [REMOTE_PORT] =&gt; 41060
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739309069.7476
    [REQUEST_TIME] =&gt; 1739309069
)

[2025-02-11 21:24:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 21:24:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 21:24:30] File size: 76.63 MB
[2025-02-11 21:24:30] Download count incremented to: 46
[2025-02-11 21:24:30] Headers set for download
[2025-02-11 21:24:30] Starting file output
[2025-02-11 21:38:28] Starting download process...
[2025-02-11 21:38:28] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; http://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 74.125.77.22
    [REMOTE_PORT] =&gt; 57563
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739309908.4041
    [REQUEST_TIME] =&gt; 1739309908
)

[2025-02-11 21:38:28] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 21:38:28] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 21:38:28] File size: 76.63 MB
[2025-02-11 21:38:28] Download count incremented to: 47
[2025-02-11 21:38:28] Headers set for download
[2025-02-11 21:38:28] Starting file output
[2025-02-11 21:38:34] File output complete. Total bytes read: 76.63 MB
[2025-02-11 21:39:02] Starting download process...
[2025-02-11 21:39:02] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; http://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 74.125.114.4
    [REMOTE_PORT] =&gt; 33468
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739309941.8118
    [REQUEST_TIME] =&gt; 1739309941
)

[2025-02-11 21:39:02] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-11 21:39:02] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-11 21:39:02] File size: 76.63 MB
[2025-02-11 21:39:02] Download count incremented to: 48
[2025-02-11 21:39:02] Headers set for download
[2025-02-11 21:39:02] Starting file output
[2025-02-11 21:39:06] File output complete. Total bytes read: 76.63 MB
[2025-02-12 05:21:40] Starting download process...
[2025-02-12 05:21:40] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT_ENCODING] =&gt; gzip,deflate
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 44.228.242.45
    [REMOTE_PORT] =&gt; 51441
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; HEAD
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739337700.0941
    [REQUEST_TIME] =&gt; 1739337700
)

[2025-02-12 05:21:40] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 05:21:40] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 05:21:40] File size: 76.63 MB
[2025-02-12 05:21:40] Download count incremented to: 49
[2025-02-12 05:21:40] Headers set for download
[2025-02-12 05:21:40] Starting file output
[2025-02-12 05:21:47] File output complete. Total bytes read: 76.63 MB
[2025-02-12 08:02:29] Starting download process...
[2025-02-12 08:02:29] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, br, deflate
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.2; +https://openai.com/gptbot)
    [HTTP_X_OPENAI_HOST_HASH] =&gt; 320209467
    [HTTP_FROM] =&gt; gptbot(at)openai.com
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 20.171.207.146
    [REMOTE_PORT] =&gt; 45190
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739347349.4321
    [REQUEST_TIME] =&gt; 1739347349
)

[2025-02-12 08:02:29] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 08:02:29] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 08:02:29] File size: 76.63 MB
[2025-02-12 08:02:29] Download count incremented to: 50
[2025-02-12 08:02:29] Headers set for download
[2025-02-12 08:02:29] Starting file output
[2025-02-12 08:02:40] File output complete. Total bytes read: 76.63 MB
[2025-02-12 10:59:44] Starting download process...
[2025-02-12 10:59:44] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,text/plain,*/*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip,deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-us,en;q=0.8
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (compatible; ips-agent)
    [HTTP_FROM] =&gt; wc@verisign.com
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 72.13.46.5
    [REMOTE_PORT] =&gt; 57904
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739357983.727
    [REQUEST_TIME] =&gt; 1739357983
)

[2025-02-12 10:59:44] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 10:59:44] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 10:59:44] File size: 76.63 MB
[2025-02-12 10:59:44] Download count incremented to: 51
[2025-02-12 10:59:44] Headers set for download
[2025-02-12 10:59:44] Starting file output
[2025-02-12 10:59:50] File output complete. Total bytes read: 76.63 MB
[2025-02-12 13:55:35] Starting download process...
[2025-02-12 13:55:35] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; http://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.253.218.48
    [REMOTE_PORT] =&gt; 37337
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739368534.7671
    [REQUEST_TIME] =&gt; 1739368534
)

[2025-02-12 13:55:35] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 13:55:35] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 13:55:35] File size: 76.63 MB
[2025-02-12 13:55:35] Download count incremented to: 52
[2025-02-12 13:55:35] Headers set for download
[2025-02-12 13:55:35] Starting file output
[2025-02-12 13:55:42] File output complete. Total bytes read: 76.63 MB
[2025-02-12 13:56:20] Starting download process...
[2025-02-12 13:56:20] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; http://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.253.254.48
    [REMOTE_PORT] =&gt; 55846
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739368580.3547
    [REQUEST_TIME] =&gt; 1739368580
)

[2025-02-12 13:56:20] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 13:56:20] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 13:56:20] File size: 76.63 MB
[2025-02-12 13:56:20] Download count incremented to: 53
[2025-02-12 13:56:20] Headers set for download
[2025-02-12 13:56:20] Starting file output
[2025-02-12 13:56:28] File output complete. Total bytes read: 76.63 MB
[2025-02-12 17:03:02] Starting download process...
[2025-02-12 17:03:02] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36
    [HTTP_FROM] =&gt; bingbot(at)microsoft.com
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 40.77.167.224
    [REMOTE_PORT] =&gt; 41152
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739379781.7739
    [REQUEST_TIME] =&gt; 1739379781
)

[2025-02-12 17:03:02] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352982
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 17:03:02] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 17:03:02] File size: 76.63 MB
[2025-02-12 17:03:02] Download count incremented to: 54
[2025-02-12 17:03:02] Headers set for download
[2025-02-12 17:03:02] Starting file output
[2025-02-12 18:01:24] Starting download process...
[2025-02-12 18:01:24] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 159.146.115.225
    [REMOTE_PORT] =&gt; 32124
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739383283.9505
    [REQUEST_TIME] =&gt; 1739383283
)

[2025-02-12 18:01:24] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 18:01:24] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 18:01:24] File size: 76.62 MB
[2025-02-12 18:01:24] Download count incremented to: 55
[2025-02-12 18:01:24] Headers set for download
[2025-02-12 18:01:24] Starting file output
[2025-02-12 18:03:27] File output complete. Total bytes read: 76.62 MB
[2025-02-12 18:50:29] Starting download process...
[2025-02-12 18:50:29] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.58.167.18
    [REMOTE_PORT] =&gt; 55299
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739386228.9123
    [REQUEST_TIME] =&gt; 1739386228
)

[2025-02-12 18:50:29] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-12 18:50:29] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-12 18:50:29] File size: 76.62 MB
[2025-02-12 18:50:29] Download count incremented to: 56
[2025-02-12 18:50:29] Headers set for download
[2025-02-12 18:50:29] Starting file output
[2025-02-12 18:50:44] File output complete. Total bytes read: 76.62 MB
[2025-02-13 00:36:14] Starting download process...
[2025-02-13 00:36:14] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-us
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.1 Safari/605.1.15
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 108.90.189.181
    [REMOTE_PORT] =&gt; 55766
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739406974.2839
    [REQUEST_TIME] =&gt; 1739406974
)

[2025-02-13 00:36:14] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-13 00:36:14] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-13 00:36:14] File size: 76.62 MB
[2025-02-13 00:36:14] Download count incremented to: 57
[2025-02-13 00:36:14] Headers set for download
[2025-02-13 00:36:14] Starting file output
[2025-02-13 00:45:33] File output complete. Total bytes read: 76.62 MB
[2025-02-13 01:18:52] Starting download process...
[2025-02-13 01:18:52] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 69.160.160.58
    [REMOTE_PORT] =&gt; 45116
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739409532.0165
    [REQUEST_TIME] =&gt; 1739409532
)

[2025-02-13 01:18:52] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-13 01:18:52] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-13 01:18:52] File size: 76.62 MB
[2025-02-13 01:18:52] Download count incremented to: 58
[2025-02-13 01:18:52] Headers set for download
[2025-02-13 01:18:52] Starting file output
[2025-02-13 08:48:21] Starting download process...
[2025-02-13 08:48:21] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,text/plain,text/xml,text/*,application/xml,application/xhtml+xml,application/rss+xml,application/atom+xml,application/rdf+xml,application/php,application/x-php,application/x-httpd-php
    [HTTP_ACCEPT_ENCODING] =&gt; br,gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; en
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (compatible; MJ12bot/v1.4.8; http://mj12bot.com/)
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 194.247.173.99
    [REMOTE_PORT] =&gt; 53104
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739436501.5143
    [REQUEST_TIME] =&gt; 1739436501
)

[2025-02-13 08:48:21] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-13 08:48:21] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-13 08:48:21] File size: 76.62 MB
[2025-02-13 08:48:21] Download count incremented to: 59
[2025-02-13 08:48:21] Headers set for download
[2025-02-13 08:48:21] Starting file output
[2025-02-13 11:16:14] Starting download process...
[2025-02-13 11:16:14] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/125.0.6422.60 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_SEC_CH_UA] =&gt; &quot;HeadlessChrome&quot;;v=&quot;125&quot;, &quot;Chromium&quot;;v=&quot;125&quot;, &quot;Not.A/Brand&quot;;v=&quot;24&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Linux&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 34.72.176.129
    [REMOTE_PORT] =&gt; 63878
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739445373.6809
    [REQUEST_TIME] =&gt; 1739445373
)

[2025-02-13 11:16:14] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-13 11:16:14] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-13 11:16:14] File size: 76.62 MB
[2025-02-13 11:16:14] Download count incremented to: 60
[2025-02-13 11:16:14] Headers set for download
[2025-02-13 11:16:14] Starting file output
[2025-02-13 11:16:22] File output complete. Total bytes read: 76.62 MB
[2025-02-13 18:29:35] Starting download process...
[2025-02-13 18:29:35] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.128.110.17
    [REMOTE_PORT] =&gt; 43696
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739471374.6828
    [REQUEST_TIME] =&gt; 1739471374
)

[2025-02-13 18:29:35] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-13 18:29:35] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-13 18:29:35] File size: 76.62 MB
[2025-02-13 18:29:35] Download count incremented to: 61
[2025-02-13 18:29:35] Headers set for download
[2025-02-13 18:29:35] Starting file output
[2025-02-13 21:04:35] Starting download process...
[2025-02-13 21:04:35] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/signed-exchange;v=b3,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.6943.53 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)
    [HTTP_AMP_CACHE_TRANSFORM] =&gt; google;v=&quot;1..8&quot;
    [HTTP_FROM] =&gt; googlebot(at)googlebot.com
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 66.249.66.83
    [REMOTE_PORT] =&gt; 62384
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739480674.8973
    [REQUEST_TIME] =&gt; 1739480674
)

[2025-02-13 21:04:35] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-13 21:04:35] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-13 21:04:35] File size: 76.62 MB
[2025-02-13 21:04:35] Download count incremented to: 62
[2025-02-13 21:04:35] Headers set for download
[2025-02-13 21:04:35] Starting file output
[2025-02-14 11:02:38] Starting download process...
[2025-02-14 11:02:38] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; http://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/125.0.6422.60 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 34.72.176.129
    [REMOTE_PORT] =&gt; 52088
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739530958.614
    [REQUEST_TIME] =&gt; 1739530958
)

[2025-02-14 11:02:38] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 11:02:38] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 11:02:38] File size: 76.62 MB
[2025-02-14 11:02:38] Download count incremented to: 63
[2025-02-14 11:02:38] Headers set for download
[2025-02-14 11:02:38] Starting file output
[2025-02-14 11:02:49] File output complete. Total bytes read: 76.62 MB
[2025-02-14 15:21:50] Starting download process...
[2025-02-14 15:21:50] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip,deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0
    [HTTP_FROM] =&gt; support@search.yandex.ru
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 213.180.203.148
    [REMOTE_PORT] =&gt; 49242
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739546510.1165
    [REQUEST_TIME] =&gt; 1739546510
)

[2025-02-14 15:21:50] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 15:21:50] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 15:21:50] File size: 76.62 MB
[2025-02-14 15:21:50] Download count incremented to: 64
[2025-02-14 15:21:50] Headers set for download
[2025-02-14 15:21:50] Starting file output
[2025-02-14 16:46:41] Starting download process...
[2025-02-14 16:46:41] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 176.236.195.147
    [REMOTE_PORT] =&gt; 63652
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739551600.9538
    [REQUEST_TIME] =&gt; 1739551600
)

[2025-02-14 16:46:41] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 16:46:41] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 16:46:41] File size: 76.62 MB
[2025-02-14 16:46:41] Download count incremented to: 65
[2025-02-14 16:46:41] Headers set for download
[2025-02-14 16:46:41] Starting file output
[2025-02-14 16:47:15] File output complete. Total bytes read: 76.62 MB
[2025-02-14 17:15:45] Starting download process...
[2025-02-14 17:15:46] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36
    [HTTP_X_OXYLABS_RENDER] =&gt; html
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 136.0.110.116
    [REMOTE_PORT] =&gt; 27683
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739553344.97
    [REQUEST_TIME] =&gt; 1739553344
)

[2025-02-14 17:15:46] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 17:15:46] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 17:15:46] File size: 76.62 MB
[2025-02-14 17:15:46] Download count incremented to: 66
[2025-02-14 17:15:46] Headers set for download
[2025-02-14 17:15:46] Starting file output
[2025-02-14 17:15:53] File output complete. Total bytes read: 76.62 MB
[2025-02-14 17:30:21] Starting download process...
[2025-02-14 17:30:21] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 OPR/114.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Chromium&quot;;v=&quot;128&quot;, &quot;Not;A=Brand&quot;;v=&quot;24&quot;, &quot;Opera GX&quot;;v=&quot;114&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.114.234.11
    [REMOTE_PORT] =&gt; 64970
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739554220.8366
    [REQUEST_TIME] =&gt; 1739554220
)

[2025-02-14 17:30:21] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 17:30:21] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 17:30:21] File size: 76.62 MB
[2025-02-14 17:30:21] Download count incremented to: 67
[2025-02-14 17:30:21] Headers set for download
[2025-02-14 17:30:21] Starting file output
[2025-02-14 17:30:26] File output complete. Total bytes read: 76.62 MB
[2025-02-14 17:40:17] Starting download process...
[2025-02-14 17:40:17] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 OPR/114.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Chromium&quot;;v=&quot;128&quot;, &quot;Not;A=Brand&quot;;v=&quot;24&quot;, &quot;Opera GX&quot;;v=&quot;114&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.114.234.11
    [REMOTE_PORT] =&gt; 65233
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739554816.5918
    [REQUEST_TIME] =&gt; 1739554816
)

[2025-02-14 17:40:17] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 17:40:17] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 17:40:17] File size: 76.62 MB
[2025-02-14 17:40:17] Download count incremented to: 68
[2025-02-14 17:40:17] Headers set for download
[2025-02-14 17:40:17] Starting file output
[2025-02-14 17:40:21] File output complete. Total bytes read: 76.62 MB
[2025-02-14 17:46:20] Starting download process...
[2025-02-14 17:46:20] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 OPR/114.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Chromium&quot;;v=&quot;128&quot;, &quot;Not;A=Brand&quot;;v=&quot;24&quot;, &quot;Opera GX&quot;;v=&quot;114&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.114.234.11
    [REMOTE_PORT] =&gt; 59529
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739555179.6651
    [REQUEST_TIME] =&gt; 1739555179
)

[2025-02-14 17:46:20] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 17:46:20] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 17:46:20] File size: 76.62 MB
[2025-02-14 17:46:20] Download count incremented to: 69
[2025-02-14 17:46:20] Headers set for download
[2025-02-14 17:46:20] Starting file output
[2025-02-14 17:46:25] File output complete. Total bytes read: 76.62 MB
[2025-02-14 17:51:39] Starting download process...
[2025-02-14 17:51:39] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 OPR/114.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Chromium&quot;;v=&quot;128&quot;, &quot;Not;A=Brand&quot;;v=&quot;24&quot;, &quot;Opera GX&quot;;v=&quot;114&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.114.234.11
    [REMOTE_PORT] =&gt; 59694
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739555498.9474
    [REQUEST_TIME] =&gt; 1739555498
)

[2025-02-14 17:51:39] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-14 17:51:39] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-14 17:51:39] File size: 76.62 MB
[2025-02-14 17:51:39] Download count incremented to: 70
[2025-02-14 17:51:39] Headers set for download
[2025-02-14 17:51:39] Starting file output
[2025-02-14 17:51:44] File output complete. Total bytes read: 76.62 MB
[2025-02-15 00:30:41] Starting download process...
[2025-02-15 00:30:41] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not_A Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;109&quot;, &quot;Chromium&quot;;v=&quot;109&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 73.193.224.236
    [REMOTE_PORT] =&gt; 51239
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739579441.3467
    [REQUEST_TIME] =&gt; 1739579441
)

[2025-02-15 00:30:41] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 00:30:41] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 00:30:41] File size: 76.62 MB
[2025-02-15 00:30:41] Download count incremented to: 71
[2025-02-15 00:30:41] Headers set for download
[2025-02-15 00:30:41] Starting file output
[2025-02-15 00:31:37] File output complete. Total bytes read: 76.62 MB
[2025-02-15 17:42:57] Starting download process...
[2025-02-15 17:42:57] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?1
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Android&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 81.78.51.228
    [REMOTE_PORT] =&gt; 56064
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739641376.932
    [REQUEST_TIME] =&gt; 1739641376
)

[2025-02-15 17:42:57] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 17:42:57] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 17:42:57] File size: 76.62 MB
[2025-02-15 17:42:57] Download count incremented to: 72
[2025-02-15 17:42:57] Headers set for download
[2025-02-15 17:42:57] Starting file output
[2025-02-15 17:43:04] File output complete. Total bytes read: 76.62 MB
[2025-02-15 19:02:40] Starting download process...
[2025-02-15 19:02:40] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT_CHARSET] =&gt; utf-8
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.5
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; CyotekWebCopy/1.9 CyotekHTTP/6.4
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 88.234.244.158
    [REMOTE_PORT] =&gt; 16604
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; HEAD
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739646159.8323
    [REQUEST_TIME] =&gt; 1739646159
)

[2025-02-15 19:02:40] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 19:02:40] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 19:02:40] File size: 76.62 MB
[2025-02-15 19:02:40] Download count incremented to: 73
[2025-02-15 19:02:40] Headers set for download
[2025-02-15 19:02:40] Starting file output
[2025-02-15 19:02:46] File output complete. Total bytes read: 76.62 MB
[2025-02-15 19:02:47] Starting download process...
[2025-02-15 19:02:47] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT_CHARSET] =&gt; utf-8
    [HTTP_ACCEPT_ENCODING] =&gt; bzip2,br,gzip,deflate,compress
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; CyotekWebCopy/1.9 CyotekHTTP/6.4
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 88.234.244.158
    [REMOTE_PORT] =&gt; 16604
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739646166.9601
    [REQUEST_TIME] =&gt; 1739646166
)

[2025-02-15 19:02:47] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 19:02:47] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 19:02:47] File size: 76.62 MB
[2025-02-15 19:02:47] Download count incremented to: 74
[2025-02-15 19:02:47] Headers set for download
[2025-02-15 19:02:47] Starting file output
[2025-02-15 19:03:43] File output complete. Total bytes read: 76.62 MB
[2025-02-15 21:01:28] Starting download process...
[2025-02-15 21:01:28] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 71.85.54.154
    [REMOTE_PORT] =&gt; 54575
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739653287.6516
    [REQUEST_TIME] =&gt; 1739653287
)

[2025-02-15 21:01:28] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:01:28] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:01:28] File size: 76.62 MB
[2025-02-15 21:01:28] Download count incremented to: 75
[2025-02-15 21:01:28] Headers set for download
[2025-02-15 21:01:28] Starting file output
[2025-02-15 21:01:28] Starting download process...
[2025-02-15 21:01:28] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 71.85.54.154
    [REMOTE_PORT] =&gt; 54575
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739653288.4374
    [REQUEST_TIME] =&gt; 1739653288
)

[2025-02-15 21:01:28] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:01:28] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:01:28] File size: 76.62 MB
[2025-02-15 21:01:28] Download count incremented to: 76
[2025-02-15 21:01:28] Headers set for download
[2025-02-15 21:01:28] Starting file output
[2025-02-15 21:01:37] File output complete. Total bytes read: 76.62 MB
[2025-02-15 21:16:38] Starting download process...
[2025-02-15 21:16:38] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 95.70.154.119
    [REMOTE_PORT] =&gt; 63642
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739654197.7804
    [REQUEST_TIME] =&gt; 1739654197
)

[2025-02-15 21:16:38] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:16:38] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:16:38] File size: 76.62 MB
[2025-02-15 21:16:38] Download count incremented to: 77
[2025-02-15 21:16:38] Headers set for download
[2025-02-15 21:16:38] Starting file output
[2025-02-15 21:16:44] File output complete. Total bytes read: 76.62 MB
[2025-02-15 21:22:36] Starting download process...
[2025-02-15 21:22:36] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 149.34.244.167
    [REMOTE_PORT] =&gt; 40850
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739654556.0373
    [REQUEST_TIME] =&gt; 1739654556
)

[2025-02-15 21:22:36] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:22:36] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:22:36] File size: 76.62 MB
[2025-02-15 21:22:36] Download count incremented to: 78
[2025-02-15 21:22:36] Headers set for download
[2025-02-15 21:22:36] Starting file output
[2025-02-15 21:25:29] Starting download process...
[2025-02-15 21:25:29] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 69.140.170.140
    [REMOTE_PORT] =&gt; 50525
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739654729.1731
    [REQUEST_TIME] =&gt; 1739654729
)

[2025-02-15 21:25:29] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:25:29] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:25:29] File size: 76.62 MB
[2025-02-15 21:25:29] Download count incremented to: 79
[2025-02-15 21:25:29] Headers set for download
[2025-02-15 21:25:29] Starting file output
[2025-02-15 21:25:35] File output complete. Total bytes read: 76.62 MB
[2025-02-15 21:33:30] Starting download process...
[2025-02-15 21:33:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 104.28.63.99
    [REMOTE_PORT] =&gt; 45715
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739655210.1861
    [REQUEST_TIME] =&gt; 1739655210
)

[2025-02-15 21:33:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:33:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:33:30] File size: 76.62 MB
[2025-02-15 21:33:30] Download count incremented to: 80
[2025-02-15 21:33:30] Headers set for download
[2025-02-15 21:33:30] Starting file output
[2025-02-15 21:35:47] Starting download process...
[2025-02-15 21:35:47] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 104.28.63.99
    [REMOTE_PORT] =&gt; 45715
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739655346.6981
    [REQUEST_TIME] =&gt; 1739655346
)

[2025-02-15 21:35:47] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:35:47] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:35:47] File size: 76.62 MB
[2025-02-15 21:35:47] Download count incremented to: 81
[2025-02-15 21:35:47] Headers set for download
[2025-02-15 21:35:47] Starting file output
[2025-02-15 21:35:50] Starting download process...
[2025-02-15 21:35:50] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Mobile/15E148 Safari/604.1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_SITE] =&gt; none
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 104.28.63.98
    [REMOTE_PORT] =&gt; 44659
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739655350.2255
    [REQUEST_TIME] =&gt; 1739655350
)

[2025-02-15 21:35:50] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:35:50] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:35:50] File size: 76.62 MB
[2025-02-15 21:35:50] Download count incremented to: 82
[2025-02-15 21:35:50] Headers set for download
[2025-02-15 21:35:50] Starting file output
[2025-02-15 21:39:13] File output complete. Total bytes read: 76.62 MB
[2025-02-15 21:44:40] Starting download process...
[2025-02-15 21:44:40] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Mobile/15E148 Safari/604.1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_PRIORITY] =&gt; u=0, i
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 104.28.63.105
    [REMOTE_PORT] =&gt; 52565
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739655880.4825
    [REQUEST_TIME] =&gt; 1739655880
)

[2025-02-15 21:44:40] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 21:44:40] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 21:44:40] File size: 76.62 MB
[2025-02-15 21:44:40] Download count incremented to: 83
[2025-02-15 21:44:40] Headers set for download
[2025-02-15 21:44:40] Starting file output
[2025-02-15 21:46:44] File output complete. Total bytes read: 76.62 MB
[2025-02-15 22:50:01] Starting download process...
[2025-02-15 22:50:01] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/125.0.6422.60 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 104.197.69.115
    [REMOTE_PORT] =&gt; 50375
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739659800.6819
    [REQUEST_TIME] =&gt; 1739659800
)

[2025-02-15 22:50:01] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 22:50:01] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 22:50:01] File size: 76.62 MB
[2025-02-15 22:50:01] Download count incremented to: 84
[2025-02-15 22:50:01] Headers set for download
[2025-02-15 22:50:01] Starting file output
[2025-02-15 23:18:35] Starting download process...
[2025-02-15 23:18:35] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 98.97.131.28
    [REMOTE_PORT] =&gt; 23161
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739661515.1184
    [REQUEST_TIME] =&gt; 1739661515
)

[2025-02-15 23:18:35] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-15 23:18:35] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-15 23:18:35] File size: 76.62 MB
[2025-02-15 23:18:35] Download count incremented to: 85
[2025-02-15 23:18:35] Headers set for download
[2025-02-15 23:18:35] Starting file output
[2025-02-15 23:19:25] File output complete. Total bytes read: 76.62 MB
[2025-02-16 02:39:16] Starting download process...
[2025-02-16 02:39:16] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 129.226.147.7
    [REMOTE_PORT] =&gt; 53356
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739673555.5757
    [REQUEST_TIME] =&gt; 1739673555
)

[2025-02-16 02:39:16] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-16 02:39:16] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-16 02:39:16] File size: 76.62 MB
[2025-02-16 02:39:16] Download count incremented to: 86
[2025-02-16 02:39:16] Headers set for download
[2025-02-16 02:39:16] Starting file output
[2025-02-16 05:24:30] Starting download process...
[2025-02-16 05:24:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html, application/rss+xml, application/atom+xml, text/xml, text/rss+xml, application/xhtml+xml
    [HTTP_ACCEPT_ENCODING] =&gt; gzip,deflate
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (compatible; SemrushBot/7~bl; +http://www.semrush.com/bot.html)
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 185.191.171.2
    [REMOTE_PORT] =&gt; 53144
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739683470.3432
    [REQUEST_TIME] =&gt; 1739683470
)

[2025-02-16 05:24:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-16 05:24:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-16 05:24:30] File size: 76.62 MB
[2025-02-16 05:24:30] Download count incremented to: 87
[2025-02-16 05:24:30] Headers set for download
[2025-02-16 05:24:30] Starting file output
[2025-02-16 07:19:29] Starting download process...
[2025-02-16 07:19:29] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-AU,en-GB;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 110.174.158.31
    [REMOTE_PORT] =&gt; 55686
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739690369.1321
    [REQUEST_TIME] =&gt; 1739690369
)

[2025-02-16 07:19:29] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-16 07:19:29] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-16 07:19:29] File size: 76.62 MB
[2025-02-16 07:19:29] Download count incremented to: 88
[2025-02-16 07:19:29] Headers set for download
[2025-02-16 07:19:29] Starting file output
[2025-02-16 07:20:31] File output complete. Total bytes read: 76.62 MB
[2025-02-16 09:29:02] Starting download process...
[2025-02-16 09:29:02] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.253.218.52
    [REMOTE_PORT] =&gt; 39063
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739698141.9213
    [REQUEST_TIME] =&gt; 1739698141
)

[2025-02-16 09:29:02] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-16 09:29:02] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-16 09:29:02] File size: 76.62 MB
[2025-02-16 09:29:02] Download count incremented to: 89
[2025-02-16 09:29:02] Headers set for download
[2025-02-16 09:29:02] Starting file output
[2025-02-16 09:29:09] File output complete. Total bytes read: 76.62 MB
[2025-02-16 09:29:30] Starting download process...
[2025-02-16 09:29:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.253.240.4
    [REMOTE_PORT] =&gt; 51292
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739698169.6158
    [REQUEST_TIME] =&gt; 1739698169
)

[2025-02-16 09:29:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80344328
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-16 09:29:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-16 09:29:30] File size: 76.62 MB
[2025-02-16 09:29:30] Download count incremented to: 90
[2025-02-16 09:29:30] Headers set for download
[2025-02-16 09:29:30] Starting file output
[2025-02-16 09:29:34] File output complete. Total bytes read: 76.62 MB
[2025-02-16 22:25:11] Starting download process...
[2025-02-16 22:25:11] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.253.192.126
    [REMOTE_PORT] =&gt; 39766
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739744705.8481
    [REQUEST_TIME] =&gt; 1739744705
)

[2025-02-16 22:25:11] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-16 22:25:11] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-16 22:25:11] File size: 76.63 MB
[2025-02-16 22:25:11] Download count incremented to: 91
[2025-02-16 22:25:11] Headers set for download
[2025-02-16 22:25:11] Starting file output
[2025-02-16 22:25:17] File output complete. Total bytes read: 76.63 MB
[2025-02-16 22:25:51] Starting download process...
[2025-02-16 22:25:51] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.253.234.233
    [REMOTE_PORT] =&gt; 57032
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739744746.0823
    [REQUEST_TIME] =&gt; 1739744746
)

[2025-02-16 22:25:51] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-16 22:25:51] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-16 22:25:51] File size: 76.63 MB
[2025-02-16 22:25:51] Download count incremented to: 92
[2025-02-16 22:25:51] Headers set for download
[2025-02-16 22:25:51] Starting file output
[2025-02-16 22:25:55] File output complete. Total bytes read: 76.63 MB
[2025-02-17 09:42:40] Starting download process...
[2025-02-17 09:42:40] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 172.253.234.247
    [REMOTE_PORT] =&gt; 54649
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739785355.7922
    [REQUEST_TIME] =&gt; 1739785355
)

[2025-02-17 09:42:40] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 09:42:40] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 09:42:40] File size: 76.63 MB
[2025-02-17 09:42:40] Download count incremented to: 93
[2025-02-17 09:42:40] Headers set for download
[2025-02-17 09:42:40] Starting file output
[2025-02-17 09:42:47] File output complete. Total bytes read: 76.63 MB
[2025-02-17 09:43:05] Starting download process...
[2025-02-17 09:43:05] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 74.125.182.100
    [REMOTE_PORT] =&gt; 41015
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739785380.5001
    [REQUEST_TIME] =&gt; 1739785380
)

[2025-02-17 09:43:05] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 09:43:05] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 09:43:05] File size: 76.63 MB
[2025-02-17 09:43:05] Download count incremented to: 94
[2025-02-17 09:43:05] Headers set for download
[2025-02-17 09:43:05] Starting file output
[2025-02-17 09:43:11] File output complete. Total bytes read: 76.63 MB
[2025-02-17 13:28:32] Starting download process...
[2025-02-17 13:28:32] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0
    [HTTP_DNT] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 193.176.84.29
    [REMOTE_PORT] =&gt; 45690
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739798907.3122
    [REQUEST_TIME] =&gt; 1739798907
)

[2025-02-17 13:28:32] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 13:28:32] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 13:28:32] File size: 76.63 MB
[2025-02-17 13:28:32] Download count incremented to: 95
[2025-02-17 13:28:32] Headers set for download
[2025-02-17 13:28:32] Starting file output
[2025-02-17 13:28:39] File output complete. Total bytes read: 76.63 MB
[2025-02-17 13:29:25] Starting download process...
[2025-02-17 13:29:25] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0
    [HTTP_DNT] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 193.176.84.29
    [REMOTE_PORT] =&gt; 45690
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739798960.5978
    [REQUEST_TIME] =&gt; 1739798960
)

[2025-02-17 13:29:25] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 13:29:25] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 13:29:25] File size: 76.63 MB
[2025-02-17 13:29:25] Download count incremented to: 96
[2025-02-17 13:29:25] Headers set for download
[2025-02-17 13:29:25] Starting file output
[2025-02-17 13:29:31] File output complete. Total bytes read: 76.63 MB
[2025-02-17 15:59:32] Starting download process...
[2025-02-17 15:59:32] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 73.42.167.172
    [REMOTE_PORT] =&gt; 53615
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739807967.3166
    [REQUEST_TIME] =&gt; 1739807967
)

[2025-02-17 15:59:32] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 15:59:32] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 15:59:32] File size: 76.63 MB
[2025-02-17 15:59:32] Download count incremented to: 97
[2025-02-17 15:59:32] Headers set for download
[2025-02-17 15:59:32] Starting file output
[2025-02-17 15:59:38] Starting download process...
[2025-02-17 15:59:38] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 73.42.167.172
    [REMOTE_PORT] =&gt; 53621
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739807973.3248
    [REQUEST_TIME] =&gt; 1739807973
)

[2025-02-17 15:59:38] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 15:59:38] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 15:59:38] File size: 76.63 MB
[2025-02-17 15:59:38] Download count incremented to: 98
[2025-02-17 15:59:38] Headers set for download
[2025-02-17 15:59:38] Starting file output
[2025-02-17 15:59:44] Starting download process...
[2025-02-17 15:59:44] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_RANGE] =&gt; bytes=2164800-80352253
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 73.42.167.172
    [REMOTE_PORT] =&gt; 53627
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739807979.3596
    [REQUEST_TIME] =&gt; 1739807979
)

[2025-02-17 15:59:44] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 15:59:44] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 15:59:44] File size: 76.63 MB
[2025-02-17 15:59:44] Download count incremented to: 99
[2025-02-17 15:59:44] Headers set for download
[2025-02-17 15:59:44] Starting file output
[2025-02-17 15:59:45] Starting download process...
[2025-02-17 15:59:45] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_RANGE] =&gt; bytes=47507966-80352253
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 73.42.167.172
    [REMOTE_PORT] =&gt; 53631
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739807980.8085
    [REQUEST_TIME] =&gt; 1739807980
)

[2025-02-17 15:59:45] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 15:59:45] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 15:59:45] File size: 76.63 MB
[2025-02-17 15:59:45] Download count incremented to: 100
[2025-02-17 15:59:45] Headers set for download
[2025-02-17 15:59:45] Starting file output
[2025-02-17 15:59:46] File output complete. Total bytes read: 76.63 MB
[2025-02-17 15:59:49] Starting download process...
[2025-02-17 15:59:49] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_RANGE] =&gt; bytes=67258878-80352253
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 73.42.167.172
    [REMOTE_PORT] =&gt; 53634
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739807984.2109
    [REQUEST_TIME] =&gt; 1739807984
)

[2025-02-17 15:59:49] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 15:59:49] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 15:59:49] File size: 76.63 MB
[2025-02-17 15:59:49] Download count incremented to: 101
[2025-02-17 15:59:49] Headers set for download
[2025-02-17 15:59:49] Starting file output
[2025-02-17 15:59:51] Starting download process...
[2025-02-17 15:59:51] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_RANGE] =&gt; bytes=79587838-80352253
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 73.42.167.172
    [REMOTE_PORT] =&gt; 53638
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739807986.1954
    [REQUEST_TIME] =&gt; 1739807986
)

[2025-02-17 15:59:51] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 15:59:51] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 15:59:51] File size: 76.63 MB
[2025-02-17 15:59:51] Download count incremented to: 102
[2025-02-17 15:59:51] Headers set for download
[2025-02-17 15:59:51] Starting file output
[2025-02-17 16:24:04] Starting download process...
[2025-02-17 16:24:04] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_PROXY_CONNECTION] =&gt; keep-alive
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 143.244.44.172
    [REMOTE_PORT] =&gt; 56004
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739809439.3517
    [REQUEST_TIME] =&gt; 1739809439
)

[2025-02-17 16:24:04] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 16:24:04] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 16:24:04] File size: 76.63 MB
[2025-02-17 16:24:04] Download count incremented to: 103
[2025-02-17 16:24:04] Headers set for download
[2025-02-17 16:24:04] Starting file output
[2025-02-17 16:24:19] File output complete. Total bytes read: 76.63 MB
[2025-02-17 16:56:26] Starting download process...
[2025-02-17 16:56:26] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_PRIORITY] =&gt; u=0, i
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 108.235.44.212
    [REMOTE_PORT] =&gt; 54741
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739811381.203
    [REQUEST_TIME] =&gt; 1739811381
)

[2025-02-17 16:56:26] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 16:56:26] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 16:56:26] File size: 76.63 MB
[2025-02-17 16:56:26] Download count incremented to: 104
[2025-02-17 16:56:26] Headers set for download
[2025-02-17 16:56:26] Starting file output
[2025-02-17 16:56:52] File output complete. Total bytes read: 76.63 MB
[2025-02-17 18:05:34] Starting download process...
[2025-02-17 18:05:34] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,pl-PL;q=0.8,pl;q=0.7,fr;q=0.6
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 176.139.111.181
    [REMOTE_PORT] =&gt; 54322
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739815529.1569
    [REQUEST_TIME] =&gt; 1739815529
)

[2025-02-17 18:05:34] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 18:05:34] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 18:05:34] File size: 76.63 MB
[2025-02-17 18:05:34] Download count incremented to: 105
[2025-02-17 18:05:34] Headers set for download
[2025-02-17 18:05:34] Starting file output
[2025-02-17 18:05:39] Starting download process...
[2025-02-17 18:05:39] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,pl-PL;q=0.8,pl;q=0.7,fr;q=0.6
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 176.139.111.181
    [REMOTE_PORT] =&gt; 54322
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739815534.3266
    [REQUEST_TIME] =&gt; 1739815534
)

[2025-02-17 18:05:39] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 18:05:39] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 18:05:39] File size: 76.63 MB
[2025-02-17 18:05:39] Download count incremented to: 106
[2025-02-17 18:05:39] Headers set for download
[2025-02-17 18:05:39] Starting file output
[2025-02-17 18:05:39] Starting download process...
[2025-02-17 18:05:39] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,*
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 176.139.111.181
    [REMOTE_PORT] =&gt; 54385
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739815534.6263
    [REQUEST_TIME] =&gt; 1739815534
)

[2025-02-17 18:05:39] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 18:05:39] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 18:05:39] File size: 76.63 MB
[2025-02-17 18:05:39] Download count incremented to: 107
[2025-02-17 18:05:39] Headers set for download
[2025-02-17 18:05:39] Starting file output
[2025-02-17 18:05:44] Starting download process...
[2025-02-17 18:05:44] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,pl-PL;q=0.8,pl;q=0.7,fr;q=0.6
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 176.139.111.181
    [REMOTE_PORT] =&gt; 54322
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739815539.3847
    [REQUEST_TIME] =&gt; 1739815539
)

[2025-02-17 18:05:44] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 18:05:44] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 18:05:44] File size: 76.63 MB
[2025-02-17 18:05:44] Download count incremented to: 108
[2025-02-17 18:05:44] Headers set for download
[2025-02-17 18:05:44] Starting file output
[2025-02-17 18:05:49] File output complete. Total bytes read: 76.63 MB
[2025-02-17 18:13:55] Starting download process...
[2025-02-17 18:13:55] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 72.211.181.181
    [REMOTE_PORT] =&gt; 53287
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739816030.287
    [REQUEST_TIME] =&gt; 1739816030
)

[2025-02-17 18:13:55] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 18:13:55] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 18:13:55] File size: 76.63 MB
[2025-02-17 18:13:55] Download count incremented to: 109
[2025-02-17 18:13:55] Headers set for download
[2025-02-17 18:13:55] Starting file output
[2025-02-17 18:14:07] File output complete. Total bytes read: 76.63 MB
[2025-02-17 19:39:48] Starting download process...
[2025-02-17 19:39:48] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 95.70.154.119
    [REMOTE_PORT] =&gt; 63756
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739821184.0128
    [REQUEST_TIME] =&gt; 1739821184
)

[2025-02-17 19:39:48] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 19:39:48] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 19:39:48] File size: 76.63 MB
[2025-02-17 19:39:48] Download count incremented to: 110
[2025-02-17 19:39:48] Headers set for download
[2025-02-17 19:39:48] Starting file output
[2025-02-17 19:39:53] Starting download process...
[2025-02-17 19:39:53] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 95.70.154.119
    [REMOTE_PORT] =&gt; 63756
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739821188.6601
    [REQUEST_TIME] =&gt; 1739821188
)

[2025-02-17 19:39:53] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 19:39:53] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 19:39:53] File size: 76.63 MB
[2025-02-17 19:39:53] Download count incremented to: 111
[2025-02-17 19:39:53] Headers set for download
[2025-02-17 19:39:53] Starting file output
[2025-02-17 19:39:55] File output complete. Total bytes read: 76.63 MB
[2025-02-17 19:42:00] File output complete. Total bytes read: 76.63 MB
[2025-02-17 21:50:59] Starting download process...
[2025-02-17 21:50:59] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 76.22.38.183
    [REMOTE_PORT] =&gt; 62576
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739829054.4067
    [REQUEST_TIME] =&gt; 1739829054
)

[2025-02-17 21:50:59] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 21:50:59] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 21:50:59] File size: 76.63 MB
[2025-02-17 21:50:59] Download count incremented to: 112
[2025-02-17 21:50:59] Headers set for download
[2025-02-17 21:50:59] Starting file output
[2025-02-17 21:51:08] File output complete. Total bytes read: 76.63 MB
[2025-02-17 21:52:42] Starting download process...
[2025-02-17 21:52:42] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 76.22.38.183
    [REMOTE_PORT] =&gt; 62616
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739829157.6201
    [REQUEST_TIME] =&gt; 1739829157
)

[2025-02-17 21:52:42] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 21:52:42] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 21:52:42] File size: 76.63 MB
[2025-02-17 21:52:42] Download count incremented to: 113
[2025-02-17 21:52:42] Headers set for download
[2025-02-17 21:52:42] Starting file output
[2025-02-17 22:57:23] Starting download process...
[2025-02-17 22:57:23] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 209.38.4.240
    [REMOTE_PORT] =&gt; 50017
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739833038.8532
    [REQUEST_TIME] =&gt; 1739833038
)

[2025-02-17 22:57:23] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 22:57:23] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 22:57:23] File size: 76.63 MB
[2025-02-17 22:57:23] Download count incremented to: 114
[2025-02-17 22:57:23] Headers set for download
[2025-02-17 22:57:23] Starting file output
[2025-02-17 22:57:30] File output complete. Total bytes read: 76.63 MB
[2025-02-17 23:06:00] Starting download process...
[2025-02-17 23:06:00] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 95.70.154.119
    [REMOTE_PORT] =&gt; 63908
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739833555.6523
    [REQUEST_TIME] =&gt; 1739833555
)

[2025-02-17 23:06:00] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-17 23:06:00] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-17 23:06:00] File size: 76.63 MB
[2025-02-17 23:06:00] Download count incremented to: 115
[2025-02-17 23:06:00] Headers set for download
[2025-02-17 23:06:00] Starting file output
[2025-02-17 23:09:14] File output complete. Total bytes read: 76.63 MB
[2025-02-18 00:13:48] Starting download process...
[2025-02-18 00:13:48] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; cs-CZ,cs;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 176.102.65.28
    [REMOTE_PORT] =&gt; 44321
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739837624.0319
    [REQUEST_TIME] =&gt; 1739837624
)

[2025-02-18 00:13:48] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 00:13:48] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 00:13:48] File size: 76.63 MB
[2025-02-18 00:13:48] Download count incremented to: 116
[2025-02-18 00:13:48] Headers set for download
[2025-02-18 00:13:48] Starting file output
[2025-02-18 00:13:49] Starting download process...
[2025-02-18 00:13:49] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 128.90.169.175
    [REMOTE_PORT] =&gt; 50163
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739837624.514
    [REQUEST_TIME] =&gt; 1739837624
)

[2025-02-18 00:13:49] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 00:13:49] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 00:13:49] File size: 76.63 MB
[2025-02-18 00:13:49] Download count incremented to: 117
[2025-02-18 00:13:49] Headers set for download
[2025-02-18 00:13:49] Starting file output
[2025-02-18 00:13:49] Starting download process...
[2025-02-18 00:13:49] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15
    [HTTP_TE] =&gt; trailers
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 136.36.101.211
    [REMOTE_PORT] =&gt; 44097
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739837624.8432
    [REQUEST_TIME] =&gt; 1739837624
)

[2025-02-18 00:13:49] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 00:13:49] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 00:13:49] File size: 76.63 MB
[2025-02-18 00:13:49] Download count incremented to: 118
[2025-02-18 00:13:49] Headers set for download
[2025-02-18 00:13:49] Starting file output
[2025-02-18 00:25:09] Starting download process...
[2025-02-18 00:25:09] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 37.120.233.62
    [REMOTE_PORT] =&gt; 41411
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; HEAD
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739838303.827
    [REQUEST_TIME] =&gt; 1739838303
)

[2025-02-18 00:25:09] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 00:25:09] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 00:25:09] File size: 76.63 MB
[2025-02-18 00:25:09] Download count incremented to: 119
[2025-02-18 00:25:09] Headers set for download
[2025-02-18 00:25:09] Starting file output
[2025-02-18 00:25:14] File output complete. Total bytes read: 76.63 MB
[2025-02-18 00:25:19] Starting download process...
[2025-02-18 00:25:19] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; max-age=259200
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 138.68.166.157
    [REMOTE_PORT] =&gt; 44402
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739838315.0664
    [REQUEST_TIME] =&gt; 1739838315
)

[2025-02-18 00:25:19] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 00:25:19] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 00:25:19] File size: 76.63 MB
[2025-02-18 00:25:19] Download count incremented to: 120
[2025-02-18 00:25:19] Headers set for download
[2025-02-18 00:25:19] Starting file output
[2025-02-18 00:25:22] File output complete. Total bytes read: 76.63 MB
[2025-02-18 00:25:47] Starting download process...
[2025-02-18 00:25:47] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 92.40.169.152
    [REMOTE_PORT] =&gt; 34790
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; HEAD
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739838342.2241
    [REQUEST_TIME] =&gt; 1739838342
)

[2025-02-18 00:25:47] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 00:25:47] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 00:25:47] File size: 76.63 MB
[2025-02-18 00:25:47] Download count incremented to: 121
[2025-02-18 00:25:47] Headers set for download
[2025-02-18 00:25:47] Starting file output
[2025-02-18 00:25:47] File output complete. Total bytes read: 76.63 MB
[2025-02-18 00:26:07] Starting download process...
[2025-02-18 00:26:07] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 92.40.169.151
    [REMOTE_PORT] =&gt; 64989
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739838362.498
    [REQUEST_TIME] =&gt; 1739838362
)

[2025-02-18 00:26:07] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 00:26:07] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 00:26:07] File size: 76.63 MB
[2025-02-18 00:26:07] Download count incremented to: 122
[2025-02-18 00:26:07] Headers set for download
[2025-02-18 00:26:07] Starting file output
[2025-02-18 00:26:15] File output complete. Total bytes read: 76.63 MB
[2025-02-18 02:08:10] Starting download process...
[2025-02-18 02:08:10] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USERAGENT] =&gt; 
    [HTTP_ACCEPTLANGUAGE] =&gt; 
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 52.160.47.176
    [REMOTE_PORT] =&gt; 27782
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739844485.6722
    [REQUEST_TIME] =&gt; 1739844485
)

[2025-02-18 02:08:10] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 02:08:10] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 02:08:10] File size: 76.63 MB
[2025-02-18 02:08:10] Download count incremented to: 123
[2025-02-18 02:08:10] Headers set for download
[2025-02-18 02:08:10] Starting file output
[2025-02-18 02:08:18] File output complete. Total bytes read: 76.63 MB
[2025-02-18 18:31:55] Starting download process...
[2025-02-18 18:31:55] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.135.148.92
    [REMOTE_PORT] =&gt; 50288
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739903510.3329
    [REQUEST_TIME] =&gt; 1739903510
)

[2025-02-18 18:31:55] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 18:31:55] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 18:31:55] File size: 76.63 MB
[2025-02-18 18:31:55] Download count incremented to: 124
[2025-02-18 18:31:55] Headers set for download
[2025-02-18 18:31:55] Starting file output
[2025-02-18 21:35:41] Starting download process...
[2025-02-18 21:35:41] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_DNT] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 24.40.233.189
    [REMOTE_PORT] =&gt; 51358
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739914536.3782
    [REQUEST_TIME] =&gt; 1739914536
)

[2025-02-18 21:35:41] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 21:35:41] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 21:35:41] File size: 76.63 MB
[2025-02-18 21:35:41] Download count incremented to: 125
[2025-02-18 21:35:41] Headers set for download
[2025-02-18 21:35:41] Starting file output
[2025-02-18 21:36:14] Starting download process...
[2025-02-18 21:36:14] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; cross-site
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 169.150.196.103
    [REMOTE_PORT] =&gt; 21508
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739914569.6529
    [REQUEST_TIME] =&gt; 1739914569
)

[2025-02-18 21:36:14] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 21:36:14] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 21:36:14] File size: 76.63 MB
[2025-02-18 21:36:14] Download count incremented to: 126
[2025-02-18 21:36:14] Headers set for download
[2025-02-18 21:36:14] Starting file output
[2025-02-18 21:39:08] Starting download process...
[2025-02-18 21:39:08] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_DNT] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 24.40.233.189
    [REMOTE_PORT] =&gt; 51487
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739914743.1595
    [REQUEST_TIME] =&gt; 1739914743
)

[2025-02-18 21:39:08] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 21:39:08] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 21:39:08] File size: 76.63 MB
[2025-02-18 21:39:08] Download count incremented to: 127
[2025-02-18 21:39:08] Headers set for download
[2025-02-18 21:39:08] Starting file output
[2025-02-18 21:39:13] File output complete. Total bytes read: 76.63 MB
[2025-02-18 22:10:16] Starting download process...
[2025-02-18 22:10:16] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 107.202.195.63
    [REMOTE_PORT] =&gt; 49541
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739916611.1049
    [REQUEST_TIME] =&gt; 1739916611
)

[2025-02-18 22:10:16] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 22:10:16] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 22:10:16] File size: 76.63 MB
[2025-02-18 22:10:16] Download count incremented to: 128
[2025-02-18 22:10:16] Headers set for download
[2025-02-18 22:10:16] Starting file output
[2025-02-18 22:10:27] File output complete. Total bytes read: 76.63 MB
[2025-02-18 22:10:53] Starting download process...
[2025-02-18 22:10:53] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 107.202.195.63
    [REMOTE_PORT] =&gt; 49554
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739916648.2719
    [REQUEST_TIME] =&gt; 1739916648
)

[2025-02-18 22:10:53] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 22:10:53] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 22:10:53] File size: 76.63 MB
[2025-02-18 22:10:53] Download count incremented to: 129
[2025-02-18 22:10:53] Headers set for download
[2025-02-18 22:10:53] Starting file output
[2025-02-18 22:11:08] File output complete. Total bytes read: 76.63 MB
[2025-02-18 22:17:22] Starting download process...
[2025-02-18 22:17:22] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 107.202.195.63
    [REMOTE_PORT] =&gt; 49712
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739917037.1258
    [REQUEST_TIME] =&gt; 1739917037
)

[2025-02-18 22:17:22] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 22:17:22] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 22:17:22] File size: 76.63 MB
[2025-02-18 22:17:22] Download count incremented to: 130
[2025-02-18 22:17:22] Headers set for download
[2025-02-18 22:17:22] Starting file output
[2025-02-18 22:17:30] File output complete. Total bytes read: 76.63 MB
[2025-02-18 22:17:57] Starting download process...
[2025-02-18 22:17:57] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 162.221.128.164
    [REMOTE_PORT] =&gt; 58052
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739917072.6322
    [REQUEST_TIME] =&gt; 1739917072
)

[2025-02-18 22:17:57] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 22:17:57] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 22:17:57] File size: 76.63 MB
[2025-02-18 22:17:57] Download count incremented to: 131
[2025-02-18 22:17:57] Headers set for download
[2025-02-18 22:17:57] Starting file output
[2025-02-18 22:18:05] File output complete. Total bytes read: 76.63 MB
[2025-02-18 23:26:08] Starting download process...
[2025-02-18 23:26:08] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 74.125.182.110
    [REMOTE_PORT] =&gt; 60776
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739921163.68
    [REQUEST_TIME] =&gt; 1739921163
)

[2025-02-18 23:26:08] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 23:26:08] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 23:26:08] File size: 76.63 MB
[2025-02-18 23:26:08] Download count incremented to: 132
[2025-02-18 23:26:08] Headers set for download
[2025-02-18 23:26:08] Starting file output
[2025-02-18 23:26:15] File output complete. Total bytes read: 76.63 MB
[2025-02-18 23:31:24] Starting download process...
[2025-02-18 23:31:24] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 OPR/116.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Opera GX&quot;;v=&quot;116&quot;, &quot;Chromium&quot;;v=&quot;131&quot;, &quot;Not_A Brand&quot;;v=&quot;24&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 71.197.137.168
    [REMOTE_PORT] =&gt; 63692
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739921479.5072
    [REQUEST_TIME] =&gt; 1739921479
)

[2025-02-18 23:31:24] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-18 23:31:24] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-18 23:31:24] File size: 76.63 MB
[2025-02-18 23:31:24] Download count incremented to: 133
[2025-02-18 23:31:24] Headers set for download
[2025-02-18 23:31:24] Starting file output
[2025-02-18 23:31:31] File output complete. Total bytes read: 76.63 MB
[2025-02-19 00:21:08] Starting download process...
[2025-02-19 00:21:08] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 71.236.158.182
    [REMOTE_PORT] =&gt; 62039
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739924463.7999
    [REQUEST_TIME] =&gt; 1739924463
)

[2025-02-19 00:21:08] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 00:21:08] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 00:21:08] File size: 76.63 MB
[2025-02-19 00:21:08] Download count incremented to: 134
[2025-02-19 00:21:08] Headers set for download
[2025-02-19 00:21:08] Starting file output
[2025-02-19 00:21:16] File output complete. Total bytes read: 76.63 MB
[2025-02-19 09:43:33] Starting download process...
[2025-02-19 09:43:33] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.155.195.141
    [REMOTE_PORT] =&gt; 46732
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739958208.9848
    [REQUEST_TIME] =&gt; 1739958208
)

[2025-02-19 09:43:33] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80352254
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 09:43:33] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 09:43:33] File size: 76.63 MB
[2025-02-19 09:43:33] Download count incremented to: 135
[2025-02-19 09:43:33] Headers set for download
[2025-02-19 09:43:33] Starting file output
[2025-02-19 15:29:04] Starting download process...
[2025-02-19 15:29:04] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_COOKIE] =&gt; _ga=GA1.1.1970960087.1738941091; _ga_XXXXXXXXXX=GS1.1.1738941090.1.0.1738941092.0.0.0
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 78.190.166.28
    [REMOTE_PORT] =&gt; 41474
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739978939.5526
    [REQUEST_TIME] =&gt; 1739978939
)

[2025-02-19 15:29:04] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 15:29:04] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 15:29:04] File size: 76.63 MB
[2025-02-19 15:29:04] Download count incremented to: 136
[2025-02-19 15:29:04] Headers set for download
[2025-02-19 15:29:04] Starting file output
[2025-02-19 15:29:11] Starting download process...
[2025-02-19 15:29:11] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_COOKIE] =&gt; _ga=GA1.1.1970960087.1738941091; _ga_XXXXXXXXXX=GS1.1.1738941090.1.0.1738941092.0.0.0
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 78.190.166.28
    [REMOTE_PORT] =&gt; 41474
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739978946.141
    [REQUEST_TIME] =&gt; 1739978946
)

[2025-02-19 15:29:11] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 15:29:11] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 15:29:11] File size: 76.63 MB
[2025-02-19 15:29:11] Download count incremented to: 137
[2025-02-19 15:29:11] Headers set for download
[2025-02-19 15:29:11] Starting file output
[2025-02-19 15:29:35] File output complete. Total bytes read: 76.63 MB
[2025-02-19 17:07:02] Starting download process...
[2025-02-19 17:07:02] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; ko,en-US;q=0.9,en;q=0.8,ja;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 125.176.231.48
    [REMOTE_PORT] =&gt; 9787
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739984817.7514
    [REQUEST_TIME] =&gt; 1739984817
)

[2025-02-19 17:07:02] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 17:07:02] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 17:07:02] File size: 76.63 MB
[2025-02-19 17:07:02] Download count incremented to: 138
[2025-02-19 17:07:02] Headers set for download
[2025-02-19 17:07:02] Starting file output
[2025-02-19 17:07:25] File output complete. Total bytes read: 76.63 MB
[2025-02-19 20:03:04] Starting download process...
[2025-02-19 20:03:04] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 7303
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995379.5037
    [REQUEST_TIME] =&gt; 1739995379
)

[2025-02-19 20:03:04] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:04] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:04] File size: 76.63 MB
[2025-02-19 20:03:04] Download count incremented to: 139
[2025-02-19 20:03:04] Headers set for download
[2025-02-19 20:03:04] Starting file output
[2025-02-19 20:03:11] Starting download process...
[2025-02-19 20:03:11] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 7079
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995386.3996
    [REQUEST_TIME] =&gt; 1739995386
)

[2025-02-19 20:03:11] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:11] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:11] File size: 76.63 MB
[2025-02-19 20:03:11] Download count incremented to: 140
[2025-02-19 20:03:11] Headers set for download
[2025-02-19 20:03:11] Starting file output
[2025-02-19 20:03:17] Starting download process...
[2025-02-19 20:03:17] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_RANGE] =&gt; bytes=2164800-80355733
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 7616
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995392.6313
    [REQUEST_TIME] =&gt; 1739995392
)

[2025-02-19 20:03:17] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:17] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:17] File size: 76.63 MB
[2025-02-19 20:03:17] Download count incremented to: 141
[2025-02-19 20:03:17] Headers set for download
[2025-02-19 20:03:17] Starting file output
[2025-02-19 20:03:19] Starting download process...
[2025-02-19 20:03:19] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_RANGE] =&gt; bytes=42795210-80355733
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 7778
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995394.9141
    [REQUEST_TIME] =&gt; 1739995394
)

[2025-02-19 20:03:19] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:19] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:19] File size: 76.63 MB
[2025-02-19 20:03:19] Download count incremented to: 142
[2025-02-19 20:03:19] Headers set for download
[2025-02-19 20:03:19] Starting file output
[2025-02-19 20:03:25] Starting download process...
[2025-02-19 20:03:25] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_RANGE] =&gt; bytes=42795210-
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 7210
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995401.063
    [REQUEST_TIME] =&gt; 1739995401
)

[2025-02-19 20:03:25] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:25] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:25] File size: 76.63 MB
[2025-02-19 20:03:25] Download count incremented to: 143
[2025-02-19 20:03:25] Headers set for download
[2025-02-19 20:03:25] Starting file output
[2025-02-19 20:03:30] Starting download process...
[2025-02-19 20:03:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_RANGE] =&gt; bytes=63340746-
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 7499
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995405.0751
    [REQUEST_TIME] =&gt; 1739995405
)

[2025-02-19 20:03:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:30] File size: 76.63 MB
[2025-02-19 20:03:30] Download count incremented to: 144
[2025-02-19 20:03:30] Headers set for download
[2025-02-19 20:03:30] Starting file output
[2025-02-19 20:03:31] File output complete. Total bytes read: 76.63 MB
[2025-02-19 20:03:34] Starting download process...
[2025-02-19 20:03:34] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_RANGE] =&gt; bytes=73867466-
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 7852
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995409.7129
    [REQUEST_TIME] =&gt; 1739995409
)

[2025-02-19 20:03:34] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:34] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:34] File size: 76.63 MB
[2025-02-19 20:03:34] Download count incremented to: 145
[2025-02-19 20:03:34] Headers set for download
[2025-02-19 20:03:34] Starting file output
[2025-02-19 20:03:36] Starting download process...
[2025-02-19 20:03:36] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; identity
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_RANGE] =&gt; bytes=79454410-
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 186.235.61.105
    [REMOTE_PORT] =&gt; 8037
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739995411.7496
    [REQUEST_TIME] =&gt; 1739995411
)

[2025-02-19 20:03:36] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:03:36] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:03:36] File size: 76.63 MB
[2025-02-19 20:03:36] Download count incremented to: 146
[2025-02-19 20:03:36] Headers set for download
[2025-02-19 20:03:36] Starting file output
[2025-02-19 20:13:42] Starting download process...
[2025-02-19 20:13:42] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 88.234.238.121
    [REMOTE_PORT] =&gt; 15781
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739996017.3576
    [REQUEST_TIME] =&gt; 1739996017
)

[2025-02-19 20:13:42] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:13:42] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:13:42] File size: 76.63 MB
[2025-02-19 20:13:42] Download count incremented to: 147
[2025-02-19 20:13:42] Headers set for download
[2025-02-19 20:13:42] Starting file output
[2025-02-19 20:14:43] File output complete. Total bytes read: 76.63 MB
[2025-02-19 20:18:17] Starting download process...
[2025-02-19 20:18:17] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 130.195.216.22
    [REMOTE_PORT] =&gt; 42859
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1739996292.7472
    [REQUEST_TIME] =&gt; 1739996292
)

[2025-02-19 20:18:17] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-19 20:18:17] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-19 20:18:17] File size: 76.63 MB
[2025-02-19 20:18:17] Download count incremented to: 148
[2025-02-19 20:18:17] Headers set for download
[2025-02-19 20:18:17] Starting file output
[2025-02-19 20:18:58] File output complete. Total bytes read: 76.63 MB
[2025-02-20 00:24:56] Starting download process...
[2025-02-20 00:24:56] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 51.89.207.163
    [REMOTE_PORT] =&gt; 47582
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740011091.5256
    [REQUEST_TIME] =&gt; 1740011091
)

[2025-02-20 00:24:56] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:24:56] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:24:56] File size: 76.63 MB
[2025-02-20 00:24:56] Download count incremented to: 149
[2025-02-20 00:24:56] Headers set for download
[2025-02-20 00:24:56] Starting file output
[2025-02-20 00:25:20] File output complete. Total bytes read: 76.63 MB
[2025-02-20 00:52:07] Starting download process...
[2025-02-20 00:52:07] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; nl-NL
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Win32&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 143.244.41.235
    [REMOTE_PORT] =&gt; 40767
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740012721.8627
    [REQUEST_TIME] =&gt; 1740012721
)

[2025-02-20 00:52:07] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:52:07] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:52:07] File size: 76.63 MB
[2025-02-20 00:52:07] Download count incremented to: 150
[2025-02-20 00:52:07] Headers set for download
[2025-02-20 00:52:07] Starting file output
[2025-02-20 00:52:13] File output complete. Total bytes read: 76.63 MB
[2025-02-20 00:53:00] Starting download process...
[2025-02-20 00:53:00] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; http://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 23.146.243.221
    [REMOTE_PORT] =&gt; 56823
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740012775.2574
    [REQUEST_TIME] =&gt; 1740012775
)

[2025-02-20 00:53:00] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:53:00] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:53:00] File size: 76.63 MB
[2025-02-20 00:53:00] Download count incremented to: 151
[2025-02-20 00:53:00] Headers set for download
[2025-02-20 00:53:00] Starting file output
[2025-02-20 00:53:00] File output complete. Total bytes read: 76.63 MB
[2025-02-20 00:56:21] Starting download process...
[2025-02-20 00:56:21] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; nl-NL,nl;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0
    [HTTP_TE] =&gt; trailers
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 146.70.108.173
    [REMOTE_PORT] =&gt; 44713
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740012976.3888
    [REQUEST_TIME] =&gt; 1740012976
)

[2025-02-20 00:56:21] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:56:21] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:56:21] File size: 76.63 MB
[2025-02-20 00:56:21] Download count incremented to: 152
[2025-02-20 00:56:21] Headers set for download
[2025-02-20 00:56:21] Starting file output
[2025-02-20 00:56:23] Starting download process...
[2025-02-20 00:56:23] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; nl-NL,nl;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15
    [HTTP_TE] =&gt; trailers
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 146.70.108.173
    [REMOTE_PORT] =&gt; 32933
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740012978.1457
    [REQUEST_TIME] =&gt; 1740012978
)

[2025-02-20 00:56:23] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:56:23] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:56:23] File size: 76.63 MB
[2025-02-20 00:56:23] Download count incremented to: 153
[2025-02-20 00:56:23] Headers set for download
[2025-02-20 00:56:23] Starting file output
[2025-02-20 00:56:23] Starting download process...
[2025-02-20 00:56:23] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 149.102.229.210
    [REMOTE_PORT] =&gt; 51817
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740012979.0445
    [REQUEST_TIME] =&gt; 1740012979
)

[2025-02-20 00:56:23] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:56:23] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:56:23] File size: 76.63 MB
[2025-02-20 00:56:23] Download count incremented to: 154
[2025-02-20 00:56:23] Headers set for download
[2025-02-20 00:56:23] Starting file output
[2025-02-20 00:57:20] Starting download process...
[2025-02-20 00:57:20] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 128.90.169.131
    [REMOTE_PORT] =&gt; 55713
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013035.3313
    [REQUEST_TIME] =&gt; 1740013035
)

[2025-02-20 00:57:20] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:57:20] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:57:20] File size: 76.63 MB
[2025-02-20 00:57:20] Download count incremented to: 155
[2025-02-20 00:57:20] Headers set for download
[2025-02-20 00:57:20] Starting file output
[2025-02-20 00:57:21] Starting download process...
[2025-02-20 00:57:21] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 149.102.229.210
    [REMOTE_PORT] =&gt; 56639
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013036.1165
    [REQUEST_TIME] =&gt; 1740013036
)

[2025-02-20 00:57:21] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:57:21] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:57:21] File size: 76.63 MB
[2025-02-20 00:57:21] Download count incremented to: 156
[2025-02-20 00:57:21] Headers set for download
[2025-02-20 00:57:21] Starting file output
[2025-02-20 00:57:22] Starting download process...
[2025-02-20 00:57:22] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 18.102.206.75
    [REMOTE_PORT] =&gt; 39031
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013037.5614
    [REQUEST_TIME] =&gt; 1740013037
)

[2025-02-20 00:57:22] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 00:57:22] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 00:57:22] File size: 76.63 MB
[2025-02-20 00:57:22] Download count incremented to: 157
[2025-02-20 00:57:22] Headers set for download
[2025-02-20 00:57:22] Starting file output
[2025-02-20 01:06:20] Starting download process...
[2025-02-20 01:06:20] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; TE, close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 37.120.233.56
    [REMOTE_PORT] =&gt; 52283
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; HEAD
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013575.7599
    [REQUEST_TIME] =&gt; 1740013575
)

[2025-02-20 01:06:20] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 01:06:20] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 01:06:20] File size: 76.63 MB
[2025-02-20 01:06:20] Download count incremented to: 158
[2025-02-20 01:06:20] Headers set for download
[2025-02-20 01:06:20] Starting file output
[2025-02-20 01:06:27] File output complete. Total bytes read: 76.63 MB
[2025-02-20 01:06:33] Starting download process...
[2025-02-20 01:06:33] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; TE, close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 206.189.247.132
    [REMOTE_PORT] =&gt; 57639
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013588.0554
    [REQUEST_TIME] =&gt; 1740013588
)

[2025-02-20 01:06:33] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 01:06:33] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 01:06:33] File size: 76.63 MB
[2025-02-20 01:06:33] Download count incremented to: 159
[2025-02-20 01:06:33] Headers set for download
[2025-02-20 01:06:33] Starting file output
[2025-02-20 01:06:35] File output complete. Total bytes read: 76.63 MB
[2025-02-20 01:06:45] Starting download process...
[2025-02-20 01:06:45] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; TE, close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 86.155.132.135
    [REMOTE_PORT] =&gt; 53595
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; HEAD
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013600.2525
    [REQUEST_TIME] =&gt; 1740013600
)

[2025-02-20 01:06:45] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 01:06:45] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 01:06:45] File size: 76.63 MB
[2025-02-20 01:06:45] Download count incremented to: 160
[2025-02-20 01:06:45] Headers set for download
[2025-02-20 01:06:45] Starting file output
[2025-02-20 01:06:45] File output complete. Total bytes read: 76.63 MB
[2025-02-20 01:06:50] Starting download process...
[2025-02-20 01:06:50] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; TE, close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 86.155.132.135
    [REMOTE_PORT] =&gt; 48899
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013605.6625
    [REQUEST_TIME] =&gt; 1740013605
)

[2025-02-20 01:06:50] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 01:06:50] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 01:06:50] File size: 76.63 MB
[2025-02-20 01:06:50] Download count incremented to: 161
[2025-02-20 01:06:50] Headers set for download
[2025-02-20 01:06:50] Starting file output
[2025-02-20 01:06:56] File output complete. Total bytes read: 76.63 MB
[2025-02-20 01:07:47] Starting download process...
[2025-02-20 01:07:47] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1
    [HTTP_TE] =&gt; deflate,gzip;q=0.3
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 37.120.233.56
    [REMOTE_PORT] =&gt; 54661
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740013662.8344
    [REQUEST_TIME] =&gt; 1740013662
)

[2025-02-20 01:07:47] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 01:07:47] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 01:07:47] File size: 76.63 MB
[2025-02-20 01:07:47] Download count incremented to: 162
[2025-02-20 01:07:47] Headers set for download
[2025-02-20 01:07:47] Starting file output
[2025-02-20 16:16:51] Starting download process...
[2025-02-20 16:16:51] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.135.185.59
    [REMOTE_PORT] =&gt; 46890
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740068206.731
    [REQUEST_TIME] =&gt; 1740068206
)

[2025-02-20 16:16:51] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 16:16:51] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 16:16:51] File size: 76.63 MB
[2025-02-20 16:16:51] Download count incremented to: 163
[2025-02-20 16:16:51] Headers set for download
[2025-02-20 16:16:51] Starting file output
[2025-02-20 17:41:23] Starting download process...
[2025-02-20 17:41:23] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.129.51.239
    [REMOTE_PORT] =&gt; 58222
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740073278.7451
    [REQUEST_TIME] =&gt; 1740073278
)

[2025-02-20 17:41:23] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 17:41:23] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 17:41:23] File size: 76.63 MB
[2025-02-20 17:41:23] Download count incremented to: 164
[2025-02-20 17:41:23] Headers set for download
[2025-02-20 17:41:23] Starting file output
[2025-02-20 18:29:11] Starting download process...
[2025-02-20 18:29:11] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 OPR/116.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Opera GX&quot;;v=&quot;116&quot;, &quot;Chromium&quot;;v=&quot;131&quot;, &quot;Not_A Brand&quot;;v=&quot;24&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 75.35.103.21
    [REMOTE_PORT] =&gt; 64212
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_CHACHA20_POLY1305_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740076145.3815
    [REQUEST_TIME] =&gt; 1740076145
)

[2025-02-20 18:29:11] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 18:29:11] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 18:29:11] File size: 76.63 MB
[2025-02-20 18:29:11] Download count incremented to: 165
[2025-02-20 18:29:11] Headers set for download
[2025-02-20 18:29:11] Starting file output
[2025-02-20 18:29:24] File output complete. Total bytes read: 76.63 MB
[2025-02-20 19:20:30] Starting download process...
[2025-02-20 19:20:30] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,en-GB;q=0.8
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?1
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Android&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 76.34.78.144
    [REMOTE_PORT] =&gt; 49047
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740079224.9865
    [REQUEST_TIME] =&gt; 1740079224
)

[2025-02-20 19:20:30] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 19:20:30] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 19:20:30] File size: 76.63 MB
[2025-02-20 19:20:30] Download count incremented to: 166
[2025-02-20 19:20:30] Headers set for download
[2025-02-20 19:20:30] Starting file output
[2025-02-20 19:20:53] File output complete. Total bytes read: 76.63 MB
[2025-02-20 19:20:58] Starting download process...
[2025-02-20 19:20:58] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0
    [HTTP_DNT] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 193.176.84.29
    [REMOTE_PORT] =&gt; 41100
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740079253.6063
    [REQUEST_TIME] =&gt; 1740079253
)

[2025-02-20 19:20:58] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-20 19:20:58] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-20 19:20:58] File size: 76.63 MB
[2025-02-20 19:20:58] Download count incremented to: 167
[2025-02-20 19:20:58] Headers set for download
[2025-02-20 19:20:58] Starting file output
[2025-02-20 19:21:05] File output complete. Total bytes read: 76.63 MB
[2025-02-21 01:04:40] Starting download process...
[2025-02-21 01:04:40] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/direct-download.php
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 47.79.122.126
    [REMOTE_PORT] =&gt; 23287
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740099875.6495
    [REQUEST_TIME] =&gt; 1740099875
)

[2025-02-21 01:04:40] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 01:04:40] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 01:04:40] File size: 76.63 MB
[2025-02-21 01:04:40] Download count incremented to: 168
[2025-02-21 01:04:40] Headers set for download
[2025-02-21 01:04:40] Starting file output
[2025-02-21 01:42:42] Starting download process...
[2025-02-21 01:42:42] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,kn;q=0.8,hi;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?1
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Android&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 106.193.38.49
    [REMOTE_PORT] =&gt; 2517
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740102157.9323
    [REQUEST_TIME] =&gt; 1740102157
)

[2025-02-21 01:42:42] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 01:42:42] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 01:42:42] File size: 76.63 MB
[2025-02-21 01:42:42] Download count incremented to: 169
[2025-02-21 01:42:42] Headers set for download
[2025-02-21 01:42:42] Starting file output
[2025-02-21 01:43:13] File output complete. Total bytes read: 76.63 MB
[2025-02-21 02:24:54] Starting download process...
[2025-02-21 02:24:54] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.130.34.74
    [REMOTE_PORT] =&gt; 42358
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740104688.7998
    [REQUEST_TIME] =&gt; 1740104688
)

[2025-02-21 02:24:54] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 02:24:54] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 02:24:54] File size: 76.63 MB
[2025-02-21 02:24:54] Download count incremented to: 170
[2025-02-21 02:24:54] Headers set for download
[2025-02-21 02:24:54] Starting file output
[2025-02-21 05:21:14] Starting download process...
[2025-02-21 05:21:14] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;114&quot;, &quot;Chromium&quot;;v=&quot;114&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 185.91.69.125
    [REMOTE_PORT] =&gt; 54448
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740115269.691
    [REQUEST_TIME] =&gt; 1740115269
)

[2025-02-21 05:21:14] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 05:21:14] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 05:21:14] File size: 76.63 MB
[2025-02-21 05:21:14] Download count incremented to: 171
[2025-02-21 05:21:14] Headers set for download
[2025-02-21 05:21:14] Starting file output
[2025-02-21 08:15:33] Starting download process...
[2025-02-21 08:15:33] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;114&quot;, &quot;Chromium&quot;;v=&quot;114&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 5.196.160.191
    [REMOTE_PORT] =&gt; 55359
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740125728.6737
    [REQUEST_TIME] =&gt; 1740125728
)

[2025-02-21 08:15:33] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 08:15:33] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 08:15:33] File size: 76.63 MB
[2025-02-21 08:15:33] Download count incremented to: 172
[2025-02-21 08:15:33] Headers set for download
[2025-02-21 08:15:33] Starting file output
[2025-02-21 13:47:12] Starting download process...
[2025-02-21 13:47:12] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 69.160.160.51
    [REMOTE_PORT] =&gt; 52062
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740145627.6279
    [REQUEST_TIME] =&gt; 1740145627
)

[2025-02-21 13:47:12] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 13:47:12] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 13:47:12] File size: 76.63 MB
[2025-02-21 13:47:12] Download count incremented to: 173
[2025-02-21 13:47:12] Headers set for download
[2025-02-21 13:47:12] Starting file output
[2025-02-21 13:47:19] File output complete. Total bytes read: 76.63 MB
[2025-02-21 18:08:56] Starting download process...
[2025-02-21 18:08:56] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:52.0) Gecko/20100101 Firefox/52.0
    [HTTP_SENTRY_TRACE] =&gt; 2ed1a734cddd4aacb2cfc77cc3620219-a055f8f57a15944b
    [HTTP_BAGGAGE] =&gt; sentry-trace_id=2ed1a734cddd4aacb2cfc77cc3620219,sentry-environment=production,sentry-public_key=95818f1c53d441e4bad44e25fc52aa40
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 34.34.137.140
    [REMOTE_PORT] =&gt; 54152
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740161331.2541
    [REQUEST_TIME] =&gt; 1740161331
)

[2025-02-21 18:08:56] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 18:08:56] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 18:08:56] File size: 76.63 MB
[2025-02-21 18:08:56] Download count incremented to: 174
[2025-02-21 18:08:56] Headers set for download
[2025-02-21 18:08:56] Starting file output
[2025-02-21 18:09:00] Starting download process...
[2025-02-21 18:09:00] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; */*
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:52.0) Gecko/20100101 Firefox/52.0
    [HTTP_SENTRY_TRACE] =&gt; 2ed1a734cddd4aacb2cfc77cc3620219-a055f8f57a15944b
    [HTTP_BAGGAGE] =&gt; sentry-trace_id=2ed1a734cddd4aacb2cfc77cc3620219,sentry-environment=production,sentry-public_key=95818f1c53d441e4bad44e25fc52aa40
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 34.34.137.140
    [REMOTE_PORT] =&gt; 54156
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740161333.7031
    [REQUEST_TIME] =&gt; 1740161333
)

[2025-02-21 18:09:00] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 18:09:00] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 18:09:00] File size: 76.63 MB
[2025-02-21 18:09:00] Download count incremented to: 175
[2025-02-21 18:09:00] Headers set for download
[2025-02-21 18:09:00] Starting file output
[2025-02-21 18:09:04] File output complete. Total bytes read: 76.63 MB
[2025-02-21 18:17:09] Starting download process...
[2025-02-21 18:17:09] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.157.250.180
    [REMOTE_PORT] =&gt; 43552
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740161822.7941
    [REQUEST_TIME] =&gt; 1740161822
)

[2025-02-21 18:17:09] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 18:17:09] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 18:17:09] File size: 76.63 MB
[2025-02-21 18:17:09] Download count incremented to: 176
[2025-02-21 18:17:09] Headers set for download
[2025-02-21 18:17:09] Starting file output
[2025-02-21 18:49:49] Starting download process...
[2025-02-21 18:49:49] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0
    [HTTP_DNT] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 193.176.84.16
    [REMOTE_PORT] =&gt; 33234
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740163783.4661
    [REQUEST_TIME] =&gt; 1740163783
)

[2025-02-21 18:49:49] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80355734
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 18:49:49] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 18:49:49] File size: 76.63 MB
[2025-02-21 18:49:49] Download count incremented to: 177
[2025-02-21 18:49:49] Headers set for download
[2025-02-21 18:49:49] Starting file output
[2025-02-21 18:49:58] File output complete. Total bytes read: 76.63 MB
[2025-02-21 21:32:48] Starting download process...
[2025-02-21 21:32:48] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; pt-BR,pt;q=0.6
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Brave&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 179.124.247.58
    [REMOTE_PORT] =&gt; 1824
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740173563.9229
    [REQUEST_TIME] =&gt; 1740173563
)

[2025-02-21 21:32:48] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 21:32:48] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 21:32:48] File size: 76.63 MB
[2025-02-21 21:32:48] Download count incremented to: 178
[2025-02-21 21:32:48] Headers set for download
[2025-02-21 21:32:48] Starting file output
[2025-02-21 21:33:38] File output complete. Total bytes read: 76.63 MB
[2025-02-21 21:53:44] Starting download process...
[2025-02-21 21:53:44] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.7
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; https://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Brave&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_GPC] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 84.239.43.13
    [REMOTE_PORT] =&gt; 44811
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_CHACHA20_POLY1305_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740174819.6712
    [REQUEST_TIME] =&gt; 1740174819
)

[2025-02-21 21:53:44] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 21:53:44] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 21:53:44] File size: 76.63 MB
[2025-02-21 21:53:44] Download count incremented to: 179
[2025-02-21 21:53:44] Headers set for download
[2025-02-21 21:53:44] Starting file output
[2025-02-21 21:55:13] File output complete. Total bytes read: 76.63 MB
[2025-02-21 22:37:36] Starting download process...
[2025-02-21 22:37:36] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.5
    [HTTP_COOKIE] =&gt; humans_21909=1
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 34.207.145.215
    [REMOTE_PORT] =&gt; 47806
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740177451.783
    [REQUEST_TIME] =&gt; 1740177451
)

[2025-02-21 22:37:36] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-21 22:37:36] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-21 22:37:36] File size: 76.63 MB
[2025-02-21 22:37:36] Download count incremented to: 180
[2025-02-21 22:37:36] Headers set for download
[2025-02-21 22:37:36] Starting file output
[2025-02-21 22:37:45] File output complete. Total bytes read: 76.63 MB
[2025-02-22 00:05:06] Starting download process...
[2025-02-22 00:05:06] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_REFERER] =&gt; http://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_X_FORWARDED_FOR] =&gt; unknown
    [HTTP_VIA] =&gt; 1.1 varsovie (squid/5.7)
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_SITE] =&gt; none
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 51.38.135.19
    [REMOTE_PORT] =&gt; 47566
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740182701.9426
    [REQUEST_TIME] =&gt; 1740182701
)

[2025-02-22 00:05:06] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 00:05:06] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 00:05:06] File size: 76.63 MB
[2025-02-22 00:05:06] Download count incremented to: 181
[2025-02-22 00:05:06] Headers set for download
[2025-02-22 00:05:06] Starting file output
[2025-02-22 00:05:13] File output complete. Total bytes read: 76.63 MB
[2025-02-22 00:49:41] Starting download process...
[2025-02-22 00:49:41] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 Edg/92.0.902.67
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 75.119.137.209
    [REMOTE_PORT] =&gt; 51988
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740185376.4055
    [REQUEST_TIME] =&gt; 1740185376
)

[2025-02-22 00:49:41] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 00:49:41] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 00:49:41] File size: 76.63 MB
[2025-02-22 00:49:41] Download count incremented to: 182
[2025-02-22 00:49:41] Headers set for download
[2025-02-22 00:49:41] Starting file output
[2025-02-22 00:49:52] File output complete. Total bytes read: 76.63 MB
[2025-02-22 00:49:57] Starting download process...
[2025-02-22 00:49:57] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 Edg/92.0.902.67
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 75.119.137.209
    [REMOTE_PORT] =&gt; 65339
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740185392.4625
    [REQUEST_TIME] =&gt; 1740185392
)

[2025-02-22 00:49:57] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 00:49:57] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 00:49:57] File size: 76.63 MB
[2025-02-22 00:49:57] Download count incremented to: 183
[2025-02-22 00:49:57] Headers set for download
[2025-02-22 00:49:57] Starting file output
[2025-02-22 00:50:13] File output complete. Total bytes read: 76.63 MB
[2025-02-22 00:50:17] Starting download process...
[2025-02-22 00:50:17] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36 Edg/92.0.902.67
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 75.119.137.209
    [REMOTE_PORT] =&gt; 60592
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740185412.1258
    [REQUEST_TIME] =&gt; 1740185412
)

[2025-02-22 00:50:17] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 00:50:17] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 00:50:17] File size: 76.63 MB
[2025-02-22 00:50:17] Download count incremented to: 184
[2025-02-22 00:50:17] Headers set for download
[2025-02-22 00:50:17] Starting file output
[2025-02-22 00:50:40] File output complete. Total bytes read: 76.63 MB
[2025-02-22 01:39:11] Starting download process...
[2025-02-22 01:39:11] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Google Chrome&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 77.201.32.176
    [REMOTE_PORT] =&gt; 59507
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740188346.7974
    [REQUEST_TIME] =&gt; 1740188346
)

[2025-02-22 01:39:11] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 01:39:11] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 01:39:11] File size: 76.63 MB
[2025-02-22 01:39:11] Download count incremented to: 185
[2025-02-22 01:39:11] Headers set for download
[2025-02-22 01:39:11] Starting file output
[2025-02-22 01:39:18] File output complete. Total bytes read: 76.63 MB
[2025-02-22 15:28:47] Starting download process...
[2025-02-22 15:28:47] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 49.51.183.220
    [REMOTE_PORT] =&gt; 54780
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740238122.2231
    [REQUEST_TIME] =&gt; 1740238122
)

[2025-02-22 15:28:47] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 15:28:47] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 15:28:47] File size: 76.63 MB
[2025-02-22 15:28:47] Download count incremented to: 186
[2025-02-22 15:28:47] Headers set for download
[2025-02-22 15:28:47] Starting file output
[2025-02-22 16:01:49] Starting download process...
[2025-02-22 16:01:49] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USERAGENT] =&gt; 
    [HTTP_ACCEPTLANGUAGE] =&gt; 
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 13.91.241.73
    [REMOTE_PORT] =&gt; 38081
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740240104.84
    [REQUEST_TIME] =&gt; 1740240104
)

[2025-02-22 16:01:49] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 16:01:49] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 16:01:49] File size: 76.63 MB
[2025-02-22 16:01:49] Download count incremented to: 187
[2025-02-22 16:01:49] Headers set for download
[2025-02-22 16:01:49] Starting file output
[2025-02-22 16:01:57] File output complete. Total bytes read: 76.63 MB
[2025-02-22 19:51:06] Starting download process...
[2025-02-22 19:51:06] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,fr-CA;q=0.8,fr-FR;q=0.7,fr;q=0.6
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_DNT] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 24.202.137.3
    [REMOTE_PORT] =&gt; 52254
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_CHACHA20_POLY1305_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740253861.5926
    [REQUEST_TIME] =&gt; 1740253861
)

[2025-02-22 19:51:06] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 19:51:06] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 19:51:06] File size: 76.63 MB
[2025-02-22 19:51:06] Download count incremented to: 188
[2025-02-22 19:51:06] Headers set for download
[2025-02-22 19:51:06] Starting file output
[2025-02-22 19:51:15] File output complete. Total bytes read: 76.63 MB
[2025-02-22 20:04:07] Starting download process...
[2025-02-22 20:04:07] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,fr-CA;q=0.8,fr-FR;q=0.7,fr;q=0.6
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_DNT] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 24.202.137.3
    [REMOTE_PORT] =&gt; 52627
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_CHACHA20_POLY1305_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740254642.5956
    [REQUEST_TIME] =&gt; 1740254642
)

[2025-02-22 20:04:07] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 20:04:07] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 20:04:07] File size: 76.63 MB
[2025-02-22 20:04:07] Download count incremented to: 189
[2025-02-22 20:04:07] Headers set for download
[2025-02-22 20:04:07] Starting file output
[2025-02-22 20:04:11] Starting download process...
[2025-02-22 20:04:12] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9,fr-CA;q=0.8,fr-FR;q=0.7,fr;q=0.6
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0
    [HTTP_SEC_CH_UA] =&gt; &quot;Not(A:Brand&quot;;v=&quot;99&quot;, &quot;Microsoft Edge&quot;;v=&quot;133&quot;, &quot;Chromium&quot;;v=&quot;133&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Windows&quot;
    [HTTP_DNT] =&gt; 1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 24.202.137.3
    [REMOTE_PORT] =&gt; 52627
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_CHACHA20_POLY1305_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740254646.9082
    [REQUEST_TIME] =&gt; 1740254646
)

[2025-02-22 20:04:12] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 20:04:12] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 20:04:12] File size: 76.63 MB
[2025-02-22 20:04:12] Download count incremented to: 190
[2025-02-22 20:04:12] Headers set for download
[2025-02-22 20:04:12] Starting file output
[2025-02-22 20:04:13] File output complete. Total bytes read: 76.63 MB
[2025-02-22 20:04:23] File output complete. Total bytes read: 76.63 MB
[2025-02-22 20:17:22] Starting download process...
[2025-02-22 20:17:22] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_CONNECTION] =&gt; Keep-Alive
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USERAGENT] =&gt; 
    [HTTP_ACCEPTLANGUAGE] =&gt; 
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 20.163.150.154
    [REMOTE_PORT] =&gt; 19315
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740255437.7584
    [REQUEST_TIME] =&gt; 1740255437
)

[2025-02-22 20:17:22] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 80356360
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 20:17:22] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 20:17:22] File size: 76.63 MB
[2025-02-22 20:17:22] Download count incremented to: 191
[2025-02-22 20:17:22] Headers set for download
[2025-02-22 20:17:22] Starting file output
[2025-02-22 20:17:27] File output complete. Total bytes read: 76.63 MB
[2025-02-22 23:57:58] Starting download process...
[2025-02-22 23:57:58] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 174.61.230.75
    [REMOTE_PORT] =&gt; 56471
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740268672.9829
    [REQUEST_TIME] =&gt; 1740268672
)

[2025-02-22 23:57:58] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 23:57:58] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 23:57:58] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-22 23:57:58] Error occurred: Game file not found. Please try again later.
[2025-02-22 23:58:07] Starting download process...
[2025-02-22 23:58:07] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-US,en;q=0.9
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 174.61.230.75
    [REMOTE_PORT] =&gt; 56471
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740268683.0211
    [REQUEST_TIME] =&gt; 1740268683
)

[2025-02-22 23:58:07] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-22 23:58:07] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-22 23:58:07] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-22 23:58:07] Error occurred: Game file not found. Please try again later.
[2025-02-23 00:38:34] Starting download process...
[2025-02-23 00:38:34] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate, br, zstd
    [HTTP_ACCEPT_LANGUAGE] =&gt; ar-DZ
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_REFERER] =&gt; https://www.worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36
    [HTTP_SEC_CH_UA] =&gt; &quot;Not A(Brand&quot;;v=&quot;8&quot;, &quot;Chromium&quot;;v=&quot;132&quot;, &quot;Google Chrome&quot;;v=&quot;132&quot;
    [HTTP_SEC_CH_UA_MOBILE] =&gt; ?0
    [HTTP_SEC_CH_UA_PLATFORM] =&gt; &quot;Win32&quot;
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_SEC_FETCH_SITE] =&gt; same-origin
    [HTTP_SEC_FETCH_MODE] =&gt; navigate
    [HTTP_SEC_FETCH_USER] =&gt; ?1
    [HTTP_SEC_FETCH_DEST] =&gt; document
    [HTTP_PRIORITY] =&gt; u=0, i
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 128.90.104.168
    [REMOTE_PORT] =&gt; 46947
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [X_SPDY] =&gt; HTTP2
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_128_GCM_SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740271110.0082
    [REQUEST_TIME] =&gt; 1740271110
)

[2025-02-23 00:38:34] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-23 00:38:34] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-23 00:38:34] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-23 00:38:34] Error occurred: Game file not found. Please try again later.
[2025-02-23 00:39:20] Starting download process...
[2025-02-23 00:39:20] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15
    [HTTP_TE] =&gt; trailers
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 193.36.118.234
    [REMOTE_PORT] =&gt; 37983
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740271155.7584
    [REQUEST_TIME] =&gt; 1740271155
)

[2025-02-23 00:39:20] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-23 00:39:20] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-23 00:39:20] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-23 00:39:20] Error occurred: Game file not found. Please try again later.
[2025-02-23 00:39:22] Starting download process...
[2025-02-23 00:39:22] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36
    [HTTP_TE] =&gt; trailers
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 45.136.155.238
    [REMOTE_PORT] =&gt; 52865
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740271157.5138
    [REQUEST_TIME] =&gt; 1740271157
)

[2025-02-23 00:39:22] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-23 00:39:22] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-23 00:39:22] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-23 00:39:22] Error occurred: Game file not found. Please try again later.
[2025-02-23 00:39:24] Starting download process...
[2025-02-23 00:39:24] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 128.90.169.223
    [REMOTE_PORT] =&gt; 60881
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740271159.1377
    [REQUEST_TIME] =&gt; 1740271159
)

[2025-02-23 00:39:24] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-23 00:39:24] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-23 00:39:24] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-23 00:39:24] Error occurred: Game file not found. Please try again later.
[2025-02-23 00:39:25] Starting download process...
[2025-02-23 00:39:25] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, deflate
    [HTTP_ACCEPT_LANGUAGE] =&gt; en-GB,en-US;q=0.9,en;q=0.8
    [HTTP_CONNECTION] =&gt; close, Te
    [HTTP_HOST] =&gt; www.worldwarss.com
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [HTTP_TE] =&gt; trailers
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 212.38.189.186
    [REMOTE_PORT] =&gt; 43386
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; www.worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.3
    [SSL_CIPHER] =&gt; TLS_AES_256_GCM_SHA384
    [SSL_CIPHER_USEKEYSIZE] =&gt; 256
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 256
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://www.worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740271160.9538
    [REQUEST_TIME] =&gt; 1740271160
)

[2025-02-23 00:39:25] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://www.worldwarss.com/downloads/WorldWars.rar
)

[2025-02-23 00:39:25] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-23 00:39:25] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-23 00:39:25] Error occurred: Game file not found. Please try again later.
[2025-02-23 18:15:07] Starting download process...
[2025-02-23 18:15:07] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
    [HTTP_ACCEPT_ENCODING] =&gt; gzip
    [HTTP_ACCEPT_LANGUAGE] =&gt; zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7
    [HTTP_CONNECTION] =&gt; close
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_PRAGMA] =&gt; no-cache
    [HTTP_USER_AGENT] =&gt; Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1
    [HTTP_CACHE_CONTROL] =&gt; no-cache
    [HTTP_UPGRADE_INSECURE_REQUESTS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 43.159.145.149
    [REMOTE_PORT] =&gt; 45748
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 80
    [REQUEST_SCHEME] =&gt; http
    [REQUEST_URI] =&gt; /direct-download.php
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; http://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740334497.17
    [REQUEST_TIME] =&gt; 1740334497
)

[2025-02-23 18:15:07] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; http://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-23 18:15:07] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-23 18:15:07] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-23 18:15:07] Error occurred: Game file not found. Please try again later.
[2025-02-23 18:33:35] Starting download process...
[2025-02-23 18:33:35] Server variables: Array
(
    [PATH] =&gt; /usr/local/bin:/bin:/usr/bin
    [HTTP_ACCEPT] =&gt; text/html,image/png,image/jpeg,image/pjpeg,image/x-xbitmap,image/svg+xml,image/gif;q=0.9,*/*;q=0.1
    [HTTP_ACCEPT_ENCODING] =&gt; gzip, identity;q=0.9
    [HTTP_ACCEPT_LANGUAGE] =&gt; en, *
    [HTTP_CONNECTION] =&gt; keep-alive
    [HTTP_HOST] =&gt; worldwarss.com
    [HTTP_REFERER] =&gt; http://worldwarss.com/
    [HTTP_USER_AGENT] =&gt; Mozilla/4.5 (compatible; HTTrack 3.0x; Windows 98)
    [HTTP_X_HTTPS] =&gt; 1
    [DOCUMENT_ROOT] =&gt; /home/worldwar/public_html
    [REMOTE_ADDR] =&gt; 95.7.162.208
    [REMOTE_PORT] =&gt; 55433
    [SERVER_ADDR] =&gt; 95.173.180.20
    [SERVER_NAME] =&gt; worldwarss.com
    [SERVER_ADMIN] =&gt; webmaster@worldwarss.com
    [SERVER_PORT] =&gt; 443
    [REQUEST_SCHEME] =&gt; https
    [REQUEST_URI] =&gt; /direct-download.php
    [HTTPS] =&gt; on
    [SSL_PROTOCOL] =&gt; TLSv1.2
    [SSL_CIPHER] =&gt; ECDHE-RSA-AES128-GCM-SHA256
    [SSL_CIPHER_USEKEYSIZE] =&gt; 128
    [SSL_CIPHER_ALGKEYSIZE] =&gt; 128
    [SCRIPT_FILENAME] =&gt; /home/worldwar/public_html/direct-download.php
    [QUERY_STRING] =&gt; 
    [SCRIPT_URI] =&gt; https://worldwarss.com/direct-download.php
    [SCRIPT_URL] =&gt; /direct-download.php
    [SCRIPT_NAME] =&gt; /direct-download.php
    [SERVER_PROTOCOL] =&gt; HTTP/1.1
    [SERVER_SOFTWARE] =&gt; LiteSpeed
    [REQUEST_METHOD] =&gt; GET
    [X-LSCACHE] =&gt; on,crawler
    [PHP_SELF] =&gt; /direct-download.php
    [REQUEST_TIME_FLOAT] =&gt; 1740335611.0719
    [REQUEST_TIME] =&gt; 1740335611
)

[2025-02-23 18:33:35] Game file info: Array
(
    [path] =&gt; /home/worldwar/public_html/downloads/WorldWars.rar
    [name] =&gt; WorldWars.rar
    [size] =&gt; 2684354560
    [type] =&gt; application/x-rar-compressed
    [url] =&gt; https://worldwarss.com/downloads/WorldWars.rar
)

[2025-02-23 18:33:35] Downloads directory checked: /home/worldwar/public_html/downloads
[2025-02-23 18:33:35] Game file not found at: /home/worldwar/public_html/downloads/WorldWars.rar
[2025-02-23 18:33:35] Error occurred: Game file not found. Please try again later.
                                </pre>
                            </div>
                                                    </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
     