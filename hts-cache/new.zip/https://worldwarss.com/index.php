 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta property="og:image"
        content="https://cdn.discordapp.com/attachments/1279015053739425812/1289340541569335390/image.png">
    <link rel="icon" type="image/x-icon" href="/favicon.77eae63f.ico">

    <title>World Wars - Epic Gaming Adventure</title>
    <meta name="description"
        content="Embark on an epic adventure! Become a Hero to explore realms or create your own worlds as an Architect in this immersive gaming experience.">

    <!-- CSS -->
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="/css/style.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
</head>

<body class="bg-dark">
    <!-- Loader -->
    <div id="loader" class="loader-wrapper">
        <div class="loader"></div>
    </div>

    <div id="content" style="display: none;">
        <!-- Modern Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
            <div class="container">
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <img src="/images/blacktail.png" alt="World Wars Logo"
                        class="me-2 animate__animated animate__flipInY">
                    <h1 class="mb-0 h3 text-gradient">World Wars</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item me-3">
                            <a href="https://discord.gg/crystal-siege" target="_blank" class="btn btn-discord">
                                <i class="fab fa-discord me-2"></i>Join Discord
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="direct-download.php" class="btn btn-download">
                                <i class="fas fa-download me-2"></i>Download Now
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <main>
            <!-- Hero Section -->
            <section class="hero-section position-relative vh-100 d-flex align-items-center">
                <div class="video-container">
                    <video autoplay loop muted playsinline class="w-100 h-100 object-fit-cover">
                        <source src="/media/main.22792817.mp4" type="video/mp4">
                    </video>
                    <div class="overlay"></div>
                </div>
                <div class="container position-relative z-index-1">
                    <div class="row align-items-center">
                        <div class="col-lg-7 animate__animated animate__fadeInLeft">
                            <h1 class="hero-title text-gradient mb-4">The Legendary Adventure Begins!</h1>
                            <p class="hero-text mb-4">Step into a world of mystery and magic. The Porbles have risen
                                against humanity, and the Kingdom of Pyli needs your help! Will you answer the call to
                                adventure?</p>
                            <div class="hero-buttons">
                                <a href="direct-download.php" class="btn btn-download-large me-3 pulse-animation"
                                    id="downloadBtn">
                                    <i class="fas fa-download me-2"></i>Download Now
                                    <span class="version-tag">v1.0.2</span>
                                </a>
                                <div class="download-progress d-none mt-3">
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                                    </div>
                                    <div class="download-status">
                                        <span class="status-text">Preparing download...</span>
                                        <span class="download-speed"></span>
                                    </div>
                                </div>
                                <a href="#features" class="btn btn-explore">
                                    <i class="fas fa-compass me-2"></i>Explore
                                </a>
                            </div>
                            <div class="download-info mt-3">
                                <span class="me-3"><i class="fas fa-desktop me-1"></i> Windows 10/11</span>
                            </div>
                        </div>
                        <div class="col-lg-5 d-none d-lg-block animate__animated animate__fadeInRight">
                            <div class="floating-characters">
                                <img src="/images/kal-fullbody.ebaf732e.png" alt="Game Character"
                                    class="floating-character">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="scroll-indicator">
                    <div class="mouse"></div>
                    <p>Scroll Down</p>
                </div>
            </section>
            

            <!-- Game Screenshots -->
            <section class="screenshots-section py-5">
                <div class="container">
                    <h2 class="section-title text-center mb-5">Game Screenshots</h2>
                    <div class="screenshot-gallery">
                        <div class="row g-4">
                            <div class="col-md-4">
                                <div class="screenshot-card" data-bs-toggle="modal" data-bs-target="#screenshotModal">
                                    <img src="/images/black-cat-background.36eb04ee.jpg" alt="Game Screenshot 1"
                                        class="img-fluid">
                                    <div class="screenshot-overlay">
                                        <i class="fas fa-expand"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="screenshot-card" data-bs-toggle="modal" data-bs-target="#screenshotModal">
                                    <img src="/images/melthia-background.4c1cd0c4.jpg" alt="Game Screenshot 2"
                                        class="img-fluid">
                                    <div class="screenshot-overlay">
                                        <i class="fas fa-expand"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="screenshot-card" data-bs-toggle="modal" data-bs-target="#screenshotModal">
                                    <img src="/images/old-heroes.90a4c6ea.jpg" alt="Game Screenshot 3"
                                        class="img-fluid">
                                    <div class="screenshot-overlay">
                                        <i class="fas fa-expand"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Features Section -->
            <section id="features">
                <div class="container">
                    <h2 class="section-title">Game Features</h2>
                    <div class="features-grid">
                        <div class="feature-card animate__animated animate__fadeInUp">
                            <div class="feature-icon">
                                <img src="/images/adventure.42415eaf.png" alt="Epic Adventure Icon">
                            </div>
                            <div class="feature-content">
                                <h3 class="feature-title">Epic Adventures</h3>
                                <p class="feature-text">Explore vast lands and uncover hidden secrets in a world full of
                                    wonder</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-compass"></i> Dynamic World Events</li>
                                    <li><i class="fas fa-gem"></i> Hidden Treasures</li>
                                    <li><i class="fas fa-scroll"></i> Epic Quests</li>
                                </ul>
                            </div>
                        </div>
                        <div class="feature-card animate__animated animate__fadeInUp" style="animation-delay: 0.2s">
                            <div class="feature-icon">
                                <img src="/images/battle.c14dbbb8.png" alt="Strategic Combat Icon">
                            </div>
                            <div class="feature-content">
                                <h3 class="feature-title">Strategic Combat</h3>
                                <p class="feature-text">Engage in tactical battles with unique abilities and master
                                    combat strategies</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-sword"></i> Real-time Combat</li>
                                    <li><i class="fas fa-bolt"></i> Unique Abilities</li>
                                    <li><i class="fas fa-users"></i> Team Tactics</li>
                                </ul>
                            </div>
                        </div>
                        <div class="feature-card animate__animated animate__fadeInUp" style="animation-delay: 0.4s">
                            <div class="feature-icon">
                                <img src="/images/collect.66f67f11.png" alt="Porble Collection Icon">
                            </div>
                            <div class="feature-content">
                                <h3 class="feature-title">Collect Porbles</h3>
                                <p class="feature-text">Build and customize your team with unique creatures, each with
                                    special abilities</p>
                                <ul class="feature-list">
                                    <li><i class="fas fa-dragon"></i> Rare Creatures</li>
                                    <li><i class="fas fa-star"></i> Evolution System</li>
                                    <li><i class="fas fa-crown"></i> Custom Teams</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Newsletter Section -->
            <section class="newsletter-section py-5">
                <div class="container">
                    <div class="newsletter-container text-center">
                        <h2 class="section-title mb-4">Stay Updated</h2>
                        <p class="mb-4">Subscribe to our newsletter for the latest news and exclusive offers!</p>
                        <form class="newsletter-form">
                            <div class="input-group">
                                <input type="email" class="form-control" placeholder="Enter your email">
                                <button class="btn btn-primary" type="submit">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </div>
            </section>

            <hr class="footer-divider">

            <!-- Footer Bottom -->
            <div class="row justify-content-center text-center">
                <div class="col-12 mb-3">
                    <p class="copyright">&copy; 2025 World Wars. All rights reserved.</p>
                </div>
                <div class="col-12">
                    <div class="footer-bottom-links">
                        <a href="#" id="termsLink" data-bs-toggle="modal" data-bs-target="#termsPopup">Terms of
                            Service</a>
                        <a href="#" id="privacyLink" data-bs-toggle="modal" data-bs-target="#privacyPopup">Privacy
                            Policy</a>
                    </div>
                </div>

                <!-- Terms of Service Modal -->
                <div class="modal fade" id="termsPopup" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-xl modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title">Terms of Service</h2>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Last updated: February 2025</p><p>Welcome to our gaming website. By accessing and using our website, you agree to comply with the following Terms of Service.</p><h3>1. Use of Service</h3><p>Our website provides access to online games, community interactions, and in-game purchases. You must be at least 13 years old to use our services. If you are under 18, parental guidance is recommended.</p><h3>2. User Conduct</h3><p>Users must not engage in any activities that violate laws, promote hate speech, or disrupt other users' experiences. Any misuse will result in account suspension.</p><h3>3. Intellectual Property</h3><p>All game content, including graphics, music, and gameplay mechanics, are copyrighted. Unauthorized reproduction or distribution is strictly prohibited.</p><h3>4. Privacy and Data</h3><p>We collect user data to enhance gaming experiences. Please refer to our Privacy Policy for details on data handling.</p><h3>5. Liability Limitation</h3><p>We do not guarantee uninterrupted service. We are not responsible for any data loss or in-game purchases that are lost due to technical issues.</p><h3>6. Changes to Terms</h3><p>We reserve the right to update these Terms of Service at any time. Continued use of our site after updates indicates acceptance of the new terms.</p><p>If you have questions, contact our support team.</p> <!-- Terms içeriğini çek -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Privacy Policy Modal -->
                <div class="modal fade" id="privacyPopup" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-xl modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title">Privacy Policy</h2>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <h2>Privacy Policy</h2><p><strong>Last Updated:</strong> February 2025</p><h3>1. Introduction</h3><p>Welcome to our gaming platform. Your privacy is important to us, and this Privacy Policy explains how we collect, use, and protect your data. By using our services, you agree to the terms outlined in this policy.</p><h3>2. Information We Collect</h3><ul><li><strong>Personal Information:</strong> Username, email address, and profile details.</li><li><strong>Game Data:</strong> Your gameplay statistics, achievements, and preferences.</li><li><strong>Device Information:</strong> IP address, browser type, and operating system.</li><li><strong>Cookies and Tracking Data:</strong> To enhance user experience and improve our services.</li></ul><h3>3. How We Use Your Information</h3><p>Your data is used to:</p><ul><li>Provide and improve our services.</li><li>Customize your gaming experience.</li><li>Offer customer support and respond to inquiries.</li><li>Monitor and analyze user behavior to enhance gameplay.</li><li>Prevent fraud, security breaches, and abuse.</li></ul><h3>4. Cookies and Tracking Technologies</h3><p>We use cookies to:</p><ul><li>Remember user preferences and login sessions.</li><li>Track website traffic and improve performance.</li><li>Provide personalized recommendations.</li></ul><p>You can disable cookies in your browser settings, but some features may not work properly.</p><h3>5. Third-Party Services</h3><p>We may share certain data with trusted third parties, such as:</p><ul><li><strong>Analytics Providers:</strong> Google Analytics, to track website usage.</li><li><strong>Payment Processors:</strong> To handle in-game purchases securely.</li><li><strong>Advertising Partners:</strong> To show relevant ads based on your interests.</li></ul><p>We do not sell your personal data to third parties.</p><h3>6. Data Security</h3><p>We implement security measures to protect your data from unauthorized access, modification, or loss. However, no system is 100% secure, and we cannot guarantee complete protection.</p><h3>7. User Rights</h3><p>As a user, you have the right to:</p><ul><li>Access and review the personal data we hold.</li><li>Request correction or deletion of your data.</li><li>Withdraw consent for data processing at any time.</li></ul><h3>8. Changes to This Privacy Policy</h3><p>We may update this Privacy Policy periodically. Changes will be posted on this page, and continued use of our services means you accept the updated terms.</p><h3>9. Contact Us</h3><p>If you have any questions about this Privacy Policy, please contact us at:</p><p><strong>📧 Email:</strong> support@worldwars.com</p> <!-- Privacy içeriğini çek -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </footer>
    </main>
    </div>

    <!-- Screenshot Modal -->
    <div class="modal fade" id="screenshotModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    <img src="" class="img-fluid" id="modalImage">
                </div>
            </div>
        </div>
    </div>



    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>